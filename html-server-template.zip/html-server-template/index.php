<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">

  <title>Nothing to see here...</title>
  <meta name="description" content="Nothing to see here...">
  <meta name="author" content="108Bits">

  <style>
    body { text-align: center; padding: 20px; }
   @media (min-width: 768px){
     body{ padding-top: 30px; }
   }
   h1 { font-size: 45px;color:#9CC2D3; }
   body { font: 20px Helvetica, sans-serif; color: #333; }
   article { display: block; text-align: left; max-width: 650px; margin: 0 auto; }
   a { color: #dc8100; text-decoration: none; }
   a:hover { color: #333; text-decoration: none; }
   </style>
</head>

<body>

<article>
    <h1>Koppel - Nothing to see here...</h1>
    <div>
		<p><img src="sad_robot.png"></p>
    </div>
</article>


</body>
</html>