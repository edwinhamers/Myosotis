# Docker template; nginx, php-fpm, certbot with volumes

This template is based on the nginx/Docker file template and 
https://bytegoblin.io/blog/nginx-and-lets-encrypt-with-docker-in-less-than-5-minutes

It uses best practices for nginx security (see headers), docker compose environment variables (ARGS) and standard docker compose setup for volumes and networks.

## Please note 
The Bytegoblin article is not complete or assumes existing knowledge:
- versioning is deprecated in compose.yaml
- `docker-compose` is replace with `docker compose`
- After step 2 the nginx container should be started

> If nginx is not running then certbot cannot complete the challenge to generate the certificate

- Step 3 certbot limitations

Certbot has limits on generating keys. When testing use `--dry-run` in the certbot command.

For example:
`docker compose run --rm certbot certonly --dry-run --webroot --webroot-path=/usr/share/nginx/html -d **yourdomain.com**`

## Installation

1) **Copy files**
```
cp compose.example.yaml compose.yaml
cp nginx/Dockerfile.example nginx/Dockerfile
cp nginx/vhost-example.conf nginx/vhost.conf
```

2) **Configure**
- Customize the nginx architecture, type and version in compose.yaml
- Customize the server name, domain(s) and root locations  in nginx/vhost.conf
- Customize the paths and domains in nginx/Dockerfile

> Do not uncomment the ssl server block in nginx/vhost.conf yet...

3) **Run docker**
`docker compose up -d`

This will build and start the nginx and certbot containers.
> certbot will not 'run' and is not available when running `docker ps`

> To see stopped (or debugging) containers use `docker ps -a`

4)  **Generate certificate**

When you have a fully qualified domain you can generate a certificate using certbot. For test purposes always include `--dry-run` in your command. Lets encrypt has restrictions on generating certs.

`docker compose run --rm certbot certonly --dry-run --webroot --webroot-path=/usr/share/nginx/html -d **yourdomain.com**`

Certbot should be able to generate the certificate and report this message:
> "Dry run completed succesfully"

4a) **Generate the actual certificates**

`docker compose run --rm certbot certonly --webroot --webroot-path=/usr/share/nginx/html -d **yourdomain.com**`

5) **enable ssl server block in nginx/vhost.conf**

- Enable the SSL server block by uncommenting it
- Optional: add a http -> https redirect

> Do not disable http access as certbot requires it for its challenge when renewing the certificate,

5a) **Reload nginx**

`docker compose exec nginx nginx -s reload`

6) **Renew certificate automatically**

> TO BE DONE
