<?php
echo "<h1>php test.</h1>";
echo "Move along, nothing else to see";
?>
