# Nginx, php-fpm secure docker template

> This template is for DEVELOPMENT ONLY!

## Requirements
- Docker desktop
- homebrew (mac only)
- WSL2 (windows)
- mkcert (https://github.com/FiloSottile/mkcert)

> Mkcert generates local certificates and a root (CA) certificate so your local browser will accept the ssl certificate.

## Used Domains
- ngi.test (tls, https)

## Installation
- Add `ngi.test` to `/etc/hosts` on your local machine. These are required in this template
  - Add your domains if needed
  - Alternatively, use a local dns services (Mac: dnsmasq)

- install mkcert locally
> The root CA certificate needs to be installed on the same computer where your browser is located.
> Plus, the generated certificate is only valid in combination with that root CA!

  - Mac: Install homebrew, then `brew install mkcert`
  - Windows: Use Chocolatey (`choco install mkcert`) or install in WSL2

- Generate root CA certificate. This install the root certificate in the 'Trusted Store'
  - `mkcert -install`
> When using Firefox it may require extra steps (Macos: `brew install nss`)
- `cd secrets`

Generate certificate
- `mkcert ngi.test` # This domain is required!

Copy the required files
- `cp .env.example .env` # Only required when using mysql
- `cp compose-example.yaml compose.yaml`

Add or change the credentials in .env if required
- `vi .env`

Now docker can be started
`docker compose up -d`

This should create the nginx and php-fpm containers. See `compose.yaml` for the configuration of each container.

## Special remarks

### Nginx
- The `nginx/Dockerfile` copies the certificates inside the nginx container and adjust the permission when using the nginx-unprivileged image (default)