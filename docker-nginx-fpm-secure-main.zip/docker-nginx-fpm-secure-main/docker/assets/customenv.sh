#  Custom profile environment
#  Run docker exec -it <container> /bin/bash -l to enable loading the profile
#  See Dockerfile where this file gets copied to /etc/profile.d/


# You may uncomment the following lines if you want `ls' to be colorized:
export LS_OPTIONS='-lsa --color=auto'
eval "$(dircolors)"
alias lla='ls $LS_OPTIONS'
alias ll='ls $LS_OPTIONS -tr' 
alias lld='ls $LS_OPTIONS -trd'

#Some more alias to avoid making mistakes:
#alias rm='rm -i'
#alias cp='cp -i'
#alias mv='mv -i'