<?php
    echo "<h1>Dit is nu via php. echt waar</h1>";
?>