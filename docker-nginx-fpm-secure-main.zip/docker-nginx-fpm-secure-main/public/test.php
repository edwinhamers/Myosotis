<?php
    echo "<h1>Dit is nu via php. Test.php</h1>";
    phpinfo();
?>