<?php
    echo "<h1>Dit is nu via php. in subfolder aap</h1>";
?>