#!/bin/bash
# Docker removal script
# Will remove all containers, images and volumes AT ONCE
echo "This will remove ALL Docker containers, images. Volumes can be deleted in next step..."
read -p "Are you VERY sure (y/Y)? : " answer
case $answer in
    [yY] )
        echo "It was yes"
        docker compose down --volumes --remove-orphans
        docker system prune -a -f --volumes
    ;;
    * )
        echo "Exiting..."
        exit 1
    ;;
esac

read -p "Delete ALL Volumes? This will delete ALL DATA, like databases, etc (y/Y)? : " answer
case $answer in
    [yY] )
        echo "Deleting volumes..."
        docker volume rm $(docker volume ls -qf dangling=true)        
    ;;
    * )
        echo "Exiting..."
        exit 1
    ;;
esac