# Traefik proxy with nginx and test containers

First trial using the Traefik proxy manager with Nginx with local, custom, certificates.

> This template is for DEVELOPMENT ONLY!

## Requirements
- Docker desktop
- homebrew (mac only)
- WSL2 (windows)
- mkcert (https://github.com/FiloSottile/mkcert)

> Mkcert generates local certificates and a root (CA) certificate so your local browser will accept the ssl certificate.

## Used Domains
- ngi.test (tls, https)
- amb.test (tls, http)
- whoami.localhost (http)

## Installation
- Add `ngi.test` and `amb.test` to `/etc/hosts` on your local machine. These are required in this template
  - Add your domains if needed
  - Alternatively, use a local dns services (Mac: dnsmasq)
- install mkcert locally
  - Mac: Install homebrew, then `brew install mkcert`
  - Windows: Use Chocolatey (`choco install mkcert`) or install in WSL2
- Generate root CA certificate (optional). The default install will also install the root cert
  - `mkcert -install`

> When using Firefox it may require extra steps (Macos: `brew install nss`)

- `cd traf/nginx/certs`
- Generate certificate
  - `mkcert ngi.test` This domain is required!

Now docker can be started
`docker compose up -d`

This should create the Traefik and nginx containers, plus two test containers based on traefik/whoami. See `compose.yaml` for the configuration of each container.

## Special remarks

### Nginx
- The `nginx/Dockerfile` copies the certificates inside the nginx container. But Traefik will actually handle the TLS, therefore the certificates are added to the Traefik store using the dynamic config file.

Traefik can 
1) serve as the TLS endpoint and decrypt the traffic. This traffic is then forwarded, unencrypted, to the service.
2) Traefik can forward encrypted traffic (not implemented)
3) Traefik decrypts and re-encrypts the traffic. (End-to-end encryption, not implemented)

- This container only works on TLS (443). Using http will result in a `404`

# Issues
- mkcert might not work on Windows, iow, your browser might still not accept the certificate and show an insecure connection. But it IS using https!