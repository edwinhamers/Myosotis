<?php
echo 'Welcome!';
echo "<h1>php index.php test met plus</h1>";
echo "<a href='connect.php'>Click here to connect to DB</a>";
phpinfo();