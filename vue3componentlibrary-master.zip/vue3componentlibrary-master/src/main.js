/* eslint-disable no-unused-vars */
// Imports
import { createApp } from 'vue'
import { createI18n} from 'vue-i18n'

import App from './App.vue'

// Styling
import '~/style.css'

//import loadComponents from '~/plugins'
//import '~/plugins'
import { FontAwesomeIcon } from '~/plugins/fontawesome'

// Import our custom CSS
import '~/scss/styles.scss'

// Import all of Bootstrap's JS
import * as bootstrap from 'bootstrap'

// Translations i18n imports
import nl from '~/lang/nl/nl.json'

// Constants

// i18n
const i18n = createI18n({
  locale: 'nl',
  fallbackLocale: "nl",
  allowComposition: true,
  messages: { nl }
})


const app = createApp(App)
.component('fa', FontAwesomeIcon)
.use(i18n)
app.mount('#app')