<script setup>

// IMPORTS
//import { ref, reactive, computed } from 'vue'
import ModalGeneral from '~/components/ModalGeneral.vue'
//import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome';
import TableGeneral from '~/components/TableGeneral.vue'
import ToastGeneral from '~/components/ToastGeneral.vue'
import { useToastGeneralFire } from '~/plugins/use_toast_general_fire'
import AlertGeneral from '~/components/AlertGeneral.vue'
import {ref} from 'vue'
import CardGeneral from './components/CardGeneral.vue'

// CONSTANTS (aka data)

const fields = [
{ key: 'first_name', label: 'First' },
  { key: 'last_name', label: 'Last' },
  { key: 'age', label: 'Age' },
]

const items = [
  { isActive: true, age: 40, first_name: 'Dickerson', last_name: 'Macdonald' },
  { isActive: false, age: 21, first_name: 'Larsen', last_name: 'Shaw' },
  { isActive: false, age: 89, first_name: 'Geneva', last_name: 'Wilson' },
  { isActive: true, age: 38, first_name: 'Jami', last_name: 'Carney' },
  { isActive: true, age: 40, first_name: 'Dickerson', last_name: 'Macdonald' },
  { isActive: false, age: 21, first_name: 'Larsen', last_name: 'Shaw' },
  { isActive: false, age: 89, first_name: 'Geneva', last_name: 'Wilson' }
]

const toastPos = ref(null)
const toastRole = ref(null)

// FUNCTIONS (aka methods)

</script>

<template>
  <div class="mt-5">
    <a href="https://vitejs.dev" target="_blank">
      <img src="/vite.svg" class="logo" alt="Vite logo" />
    </a>
    <a href="https://vuejs.org/" target="_blank">
      <img src="./assets/vue.svg" class="logo vue" alt="Vue logo" />
    </a>
  </div>

<CardGeneral 
  cardClass="m-5"
  id="cardexample"
  cardVariant="light"
  headerBgVariant=""
  headerClass="u1"
  :headerIconEnd="{style: 'fa-regular', name: 'edit'}"
  footer=""
  subTitle="Sub title test"
  subTitleClass="u3"
  subTitleTag="h3"
  title="Fancy Title Long"
  titleClass="u4"
  titleTag="h1"
  >
  En hier is inhoud van parent
</CardGeneral>

<ModalGeneral 
  id="exampleModal2"
  headerTitleTag="h2"
  subTitle="alerts.defaults.title"
>  
</ModalGeneral>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal2">
    Launch demo modal
  </button>


<h2>Myo Tabel</h2>
<TableGeneral 
  :items="items"
  :fields="fields"
  stickyHeader="300px"
  tableVariant="primary"
  :striped="true"
  :hover="true"
/>

<h2>Alert</h2>
<AlertGeneral
  closeVariant="dark"
  id="alertexample"
  :dismissible="true"
  :show="true"
  variant="success"
  ariaLabelDismiss="Alles"
  :titleBadge="true"
  titleBadgeVariant="success"
  >
  Hier komt inhoud voor het alert
  En nog een regel <br />
  En nog een regel
  </AlertGeneral>

  <div id="liveAlertPlaceholder"></div>
<button type="button" class="btn btn-primary" id="liveAlertBtn">Show live alert</button>
 



<h2>Toast examples</h2>

<button type="button" class="btn btn-primary" id="liveToastBtn" @click="useToastGeneralFire('toastexample')">Show live toast</button>


<ToastGeneral
 id="toastexample"
 :autohide="false"

>
  Inhoud vanuit parent
</ToastGeneral>


</template>



<style>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
 /* Urgency css. */
 .u1 {
    color: white;
    background-color: #fa6501;
  }
  .u2 {
    color: #000;
    background-color: #facc01;
  }
  .u3 {
    color: #000 !important;
    background-color: #fcff67;
  }
  .u4 {
    color: #000;
    background-color: #ccff66;
  }
  .u5 {
    color: #000;
    background-color: #85ca3a;
  }
</style>
