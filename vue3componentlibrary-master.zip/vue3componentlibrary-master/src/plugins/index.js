
const modules = import.meta.glob("~/plugins/*.js", { eager: true });

