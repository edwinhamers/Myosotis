import { Toast } from 'bootstrap'

export function useToastGeneralFire(toastId) {
  const toastElement = document.getElementById(toastId)
  if (toastElement){
    const bsToast = new Toast(toastElement)
    bsToast.show()
  } else {
    console.log('toast error: not found')
  }
}
