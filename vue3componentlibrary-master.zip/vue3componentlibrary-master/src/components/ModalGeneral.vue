<!-- eslint-disable vue/no-parsing-error -->
<!-- eslint-disable vue/return-in-computed-property -->
<script setup>

// IMPORTS
import { computed } from 'vue'
//import { Modal } from 'bootstrap'
import { useI18n } from 'vue-i18n'
// Enable this when using a toast inside the modal. Not required for 
// normal use
//import { useToastGeneralFire } from '~/plugins/use_toast_general_fire'

// CONSTS
const { t } = useI18n() // use as global scope

// PROPS
const props = defineProps({
	alertDesc: {
		type: String,
		default: '' 	// default is required for the t() function as it needs a parameter
	},
	alertShow: {
		type: Boolean,
		default: false
	},
	alertTitle: {
		type: String,
		default: '' 	// default is required for the t() function as it needs a parameter
	},
	alertTitleTag: {
		type: String,
		default: 'h5'
	},
	alertVariant: {
		type: String,
		default: "warning"
	},
	ariaLabelClose: {
    type: String,
    default: "Close"
  },
	cancelButtonSize: {
		type: String,
		default: 'md'
	},
	cancelClass: {
		type: [String,Array,Object],
	},
	cancelDisabled: {
		type: Boolean,
		default: false
	},
	cancelHide: {
		type: Boolean,
		default: false
	},
	cancelTitle: {
		type: String,
		default: "modals.defaults.cancel_title"
	},
	cancelVariant: {
		type: String,
		default: 'outline-dark'
	},
	centered: {
		type: Boolean,
		default: false
	},
	deleteButton: {
		type: Boolean,
		default: false,
	},
	deleteTitle: {
		type: String,
	},
	deleteVariant: {
		type: String,
		default: 'outline-danger'
	},
	deleteDisabled: {
		type: Boolean,
		default: false
	},
	description: {
		type: String,
		default: '' 	// default is required for the t() function as it needs a parameter
	},
	footerButtonAlignment: {
		type: String,
		default: 'left'
	},
	footerClass: {
		type: [String,Array,Object],
	},
	footerShow: {
		type: Boolean,
		default: true
	},
	headerBgVariant: {
		type: String,
		default: 'dark'
	},
	headerClass: {
		type: [String,Array,Object],
	},
	headerClientGenderIcon: {
		type: Object,
	},
	headerClientBirthdate: {
		type: String,
	},
	headerClientBirthdateIcon: {
		type: Object,
	},
	headerClientName: {
		type: String,
		default: '' 	// default is required for the t() function as it needs a parameter
	},
	headerHideClose: {
		type: Boolean,
		default: false
	},
	headerIcon: {
		type: Object,
	},
	headerTitle: {
		type: String,
		default: 'modals.defaults.title' 	// default is required for the t() function as it needs a parameter
	},
	headerTitleClass: {
		type: [String, Array, Object],
	},
	headerTitleTag: {
		type: String,
		default: "h1"
	},
	id: {
		type: [Number, String],
		required: true
	},
	modalClass: {
		type: [String,Array,Object],
	},
	noCloseOnBackdrop: {
		type: Boolean,
		default: false
	},
	noCloseOnEsc: {
		type: Boolean,
		default: false
	},
	noFade: {
		type: Boolean,
		default: false
	},
	okButtonSize: {
		type: String,
		default: 'md'
	},
	okClass: {
		type: [String,Array,Object],
	},
	okDisabled: {
		type: Boolean,
		default: false
	},
	okHide: {
		type: Boolean,
		default: false
	},
	okTitle: {
		type: String,
		default: 'modals.defaults.ok_title'
	},
	okVariant: {
		type: String,
		default: 'success'
	},
	size: {
		type: String,
	},
	scrollable: {
		type: Boolean,
		default: false
	},
	subTitle: {
		type: String,
		default: '' 	// default is required for the t() function as it needs a parameter
	},
	subTitleTag: {
		type: String,
		default: 'h2'
	}
})

/* NOTE *****************************************************

/* Translations defaults ################################
* The t() function requires a parameter and will thrown an error if empty. 
* See WR5 dev guide
*/


// COMPUTED's ##############################################


// COMPUTED PROPS ##############################

// Position the modal vertically in the center
const setCentered = computed(() => {
	if (props.centered)
		return 'modal-dialog-centered'
})

// Fade enable/disable
const setFade = computed(() => {
	if( props.noFade)
  	return props.noFade ? '' : 'fade'
})

// Footer content alingment
const setFooterButtonAlignment = computed(() => {
  let alignment = ''
	if (props.footerButtonAlignment === 'left')
		alignment="justify-content-start"
	else {
		if (props.footerButtonAlignment === 'right')
			alignment="justify-content-end"
	}
	return alignment
})

// Close modal on Backdrop
const setNoCloseOnBackdrop = computed(() => {
	if (props.noCloseOnBackdrop)
		return 'static'
})
// Close modal on ESC
const setNoCloseOnEsc = computed(() => {
	if (props.noCloseOnEsc )
		return 'false'
})

// Enable scrolling inside the modal for long content
const setScrollable = computed(() => {
	if (props.scrollable)
		return 'modal-dialog-scrollable'
})

// Set the color mode on the close button 
// -> btn-close-white has been deprecated in bootstrap 5.3.0 
//
// We match 'warning', 'info' and 'light' and display the close button in black (=light mode)
// Any 'subtle' variant will be displayed in black (=light mode)
// all other matches are displayed in white (=dark mode)

const setColorModeCloseButton = computed(() => {
		const warningrgex = /warning(.*)/g;
		const inforgex = /info(.*)/g;
		const lightrgex = /light(.*)/g;
		const subtlergex= /\bsubtle\b/g;
		
		if (!props.headerBgVariant) 
				return ''
		if (props.headerBgVariant.match(subtlergex) 
				|| props.headerBgVariant.match(warningrgex)  
				|| props.headerBgVariant.match(inforgex) 
				|| props.headerBgVariant.match(lightrgex) 
		) 
				return ''
		return 'btn-close-white'
})

// Props ==> Bootstrap Class Translations ##########################

// Translate Alert Variant to Bootstrap language
const setAlertVariant = computed(() => {
  if(props.alertVariant)
		return 'alert-' + props.alertVariant 
})

// Set Ok button size
const setCancelButtonSize = computed(() => {
	if (props.cancelButtonSize && props.cancelButtonSize === 'sm' || props.cancelButtonSize === 'lg')
		return 'btn-' + props.cancelButtonSize
})

// Translate Cancel Button to Bootstrap language
const setCancelVariant = computed( () => {
	if(props.cancelVariant)
		return 'btn-' + props.cancelVariant
})

// Set background variant
const setBackgroundVariant = computed(() => {
	if(props.headerBgVariant) {
		return 'bg-' + props.headerBgVariant
	} 
})

// Translate & Set Text variant
const setTextVariant = computed(() => {
	if(props.headerBgVariant) {
		return 'text-bg-' + props.headerBgVariant
	} 
})

// Set Ok button size
const setOkButtonSize = computed( () => {
	if (props.okButtonSize === 'sm' || props.okButtonSize === 'lg')
		return 'btn-' + props.okButtonSize
})

// Translate Ok Button to Bootstrap language
const setOkVariant = computed( () => {
	return 'btn-' + props.okVariant
})

// set Size of modal
const setSize = computed(() => {
  if(props.size)
		return 'modal-' + props.size 
})


// FUNCTIONS (aka vue2 methods) ##################################

const processOk = function() {
	const modalhide = Modal.getInstance(document.getElementById(props.id))
	modalhide.hide()
}

// EMITS ########################################################
// Define emits functions - REQUIRED
const emit = defineEmits(['ok', 'cancel', 'close' ])

// emit ok event and close modal
const emitOk = function() {
	emit('ok', 'ok')
	const modalhide = Modal.getInstance(document.getElementById(props.id))
	modalhide.hide()
}
// emit cancel event (modal is automatically closed by bootstrap)
const emitCancel = function() {
	emit('cancel', 'cancel')
}
// emit close event (modal is automatically closed by bootstrap)
const emitClose = function() {
	emit('cancel', 'close')
}
// Emit delete event
const deleteEvent = function() {
  emit('deleteEvent', 'delete')
}

</script>

<template>
	<!-- Modal -->
	<div class="modal" 
		:data-bs-keyboard="setNoCloseOnEsc" 
		:class="setFade,modalClass" 
		:data-bs-backdrop="setNoCloseOnBackdrop" 
		:id="id" 
		tabindex="-1" 
		:aria-labelledby="id" 
		aria-hidden="true"
	>
		<div class="modal-dialog" :class="setSize, setScrollable, setCentered">
			<div class="modal-content">
				
				<div class="modal-header" :class="setBackgroundVariant, setTextVariant,headerClass" >
					<component :is="headerTitleTag" class="modal-title fs-5" :class="headerTitleClass">
						<fa v-if="headerIcon" :icon="[headerIcon.style,headerIcon.name]" class="mr-1" />
						{{ t(headerTitle) }}
						<fa v-if="headerClientGenderIcon" :icon="[headerClientGenderIcon.style,headerClientGenderIcon.name]" class="mx-1" />
						{{ props.headerClientName }}
						<fa v-if="headerClientBirthdateIcon" :icon="[headerClientBirthdateIcon.style,headerClientBirthdateIcon.name]" class="mx-1" />
						{{ props.headerClientBirthdate }}
					</component>
					<button v-if="!headerHideClose"
							type="button" 
							class="btn-close opacity-75"
							:class="setColorModeCloseButton"
							data-bs-dismiss="modal" 
							:aria-label="props.ariaLabelClose"
							@click="emitClose"
						>
						</button>
				</div>

				<div class="modal-body">
					
					<component :is="subTitleTag" class="fs-5">
						{{ t(props.subTitle) }}
					</component>

					<div v-if="description">
						{{ t(props.description) }}
					</div>

					<div v-if="alertShow" 
						class="alert mt-2"
						:class="setAlertVariant"   
						role="alert"
					>
						<component :is="alertTitleTag" class="alert-heading">
							{{ t(props.alertTitle) }}
						</component>
							{{ t(props.alertDesc) }}
					</div>
					<slot></slot>
				</div>

				<div class="modal-footer" v-if="footerShow" :class="footerClass, setFooterButtonAlignment">
					<button v-if="!okHide" 
						:disabled="okDisabled" 
						type="button" 
						class="btn" 
						:class="setOkButtonSize, setOkVariant, okClass"
						aria-label="Ok"
						@click="emitOk"
					>
						{{ $t(props.okTitle) }}
					</button>

					<b-button v-if="!okOnly && deleteButton" 
						:variant="deleteVariant" 
						:disabled="deleteDisabled" 
						@click="deleteEvent"
					>
        		{{ $t(props.getDeleteTitle) }}
      		</b-button>

					<button v-if="!cancelHide" 
						:disabled="cancelDisabled" 
						type="button" 
						class="btn" 
						:class="setCancelButtonSize, setCancelVariant, cancelClass" 
						data-bs-dismiss="modal"
						aria-label="Cancel"
						@click="emitCancel"
					>
						{{ $t(props.cancelTitle) }}
					</button>

				</div>

			</div>
		</div>
	</div>
</template>

<style scoped>
</style>