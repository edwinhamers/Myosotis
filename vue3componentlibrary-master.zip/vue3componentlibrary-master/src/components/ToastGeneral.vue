<script setup>

// IMPORTS ##################################################
import { ref, computed, watch, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'

// CONSTS ####################################################
const { t } = useI18n() // use as global scope

// Accessibility constants
const role = ref('status')
const arialive = ref('polite')

// Bootstrap 5.3 Toast position translation matrix
// It uses a computed function to dynamically translate and change
// the position of the toast. 
const positions = {
    'top-left': 'top-0 start-0',
    'top-center': 'top-0 start-50 translate-middle-x',
    'top-right': 'top-0 end-0',
    'middle-left': 'top-50 start-0 translate-middle-y',
    'middle-center': 'top-50 start-50 translate-middle',
    'middle-right': 'top-50 end-0 translate-middle-y',
    'bottom-left': 'bottom-0 start-0',
    'bottom-center': 'bottom-0 start-50 translate-middle-x',
    'bottom-right': 'bottom-0 end-0'
  };

// PROPS ####################################################
const props = defineProps({
  ariaLabelClose: {
    type: String,
    default: "Close"
  },
  autohide: {
    type: Boolean,
    default: true
  },
  autohideDelay: {
    type: String,
    default: "5000"
  },
  closeVariant: {
    type: String,
    default: "dark"
  },
  darkMode: {
    type: Boolean,
    default: false
  },
  id: {
    type: String,
    required: true
  },
  fade: {
    type: Boolean,
    default: true
  },
  headerClass: {
    type: [String, Array, Object]
  },
  headerHideClose: {
    type: Boolean,
    default: false
  },
  headerVariant: {
    type: String,
  },
  position: {
    type: String,
    default: "bottom-right"
  },
  role: {
    type: String,
  },  
  subTitle: {
    type: String,
  },
  subTitleClass: {
    type: [String, Array, Object],
  },
  subTitleTag: {
    type: String,
    default: 'small'
  },
  title: {
		type: String,
		default: 'toasts.defaults.title' 	// default is required for the t() function as it needs a parameter
	},
  titleBadge: {
    type: Boolean,
    default: true
  },
  titleBadgeClass: {
    type: [String, Array, Object],
    default: "p-2 me-2"
  },
  titleBadgeVariant: {
    type: String,
    default: 'info'
  },
  titleClass: {
    type: [String, Array, Object],
    default: 'me-auto fw-bold'
  },
  titleIcon: {
		type: Object,
	},
  titleIconClass: {
    type: String,
    default: 'me-2'
  },
  titleTag: {
    type: String,
    default: 'div'
  },
  toastClass: {
    type: [String, Array, Object],
  },
  toastVariant: {
    type: String,
  },
  transparency: {
    type: Boolean,
    // Bootstrap 5.3 default is 'true'
  }
})

// COMPUTED ######################################################

// Set background variant
const setCloseVariant = computed(() => {
	if(props.closeVariant === 'light') {
		return 'btn-close-white'
	} 
})
const setTransparency = computed(() => {
	if(props.darkMode && !props.toastVariant) {
		return 'transparency-dark'
  }
  if(props.transparency && !props.darkMode) {
    return 'transparency'
  }	 
})
const setHeaderVariant = computed(() => {
	if(props.headerVariant) {
		return 'text-bg-' + props.headerVariant
	} 
})
const setTitleBadgeVariant = computed(() => {
	if(props.titleBadgeVariant) {
		return 'text-bg-' + props.titleBadgeVariant
	} 
})
const setToastVariant = computed(() => {
	if(props.toastVariant) {
		return 'border-0 text-bg-' + props.toastVariant
	} 
})

const setPosition = computed(() => {
  return positions[props.position] || 'bottom-0 end-0';
})

// WATCHERS ######################################################
watch(() => props.role, (role) => {
    setRole()
})

// FUNCTIONS (aka vue2 methods) ##################################

// Change accessibility props values depending on a watch:
const setRole = function () {
  if(props.role === "alert") {
    role.value = "alert"
    arialive.value = "assertive"
  } else {
    role.value = "status"
    arialive.value = "polite"
  }
}

// ONMOUNTED (not reactive) #################################

onMounted(() => {
  
})

</script>

<template>

<div class="toast-container position-fixed p-3" :class="setPosition">
  <div 
    :id="props.id" 
    class="toast" 
    :class="setToastVariant, toastClass, setTransparency" 
    :role="role" 
    :aria-live="arialive" 
    aria-atomic="true" 
    :data-bs-autohide="props.autohide">
    <div class="toast-header" :class="headerClass">
      <div v-if="!titleIcon && titleBadge" class="" :class="setTitleBadgeVariant, titleBadgeClass">
      </div>
      <fa v-if="titleIcon" :icon="[titleIcon.style,titleIcon.name]" :class="titleIconClass" />
      
			<component :is="titleTag" class="" :class="titleClass">
        {{ t(title) }}
      </component>
      <component v-if="subTitle" :is="subTitleTag" class="" :class="subTitleClass">
        {{ t(subTitle) }}
      </component>
      <button
        v-if="!headerHideClose"
        type="button" 
        class="btn-close" 
        :class="setCloseVariant" 
        data-bs-dismiss="toast" 
        :aria-label="props.ariaLabelClose">
      </button>
    </div>
    <div class="toast-body">
      <slot></slot>
    </div>
  </div>

</div>

</template>

<style scoped>

.transparency {
  background-color:rgba(255, 255, 255, 1)
}
/* Dark mode for toasts (until bootstrap supports dark mode natively) 
*  the toast-header needs to be targeted specifically 
*/
.transparency-dark, .transparency-dark > .toast-header {
  background-color:rgba(0, 0, 0, 1);
  color:#eee;
  border-color: #eee;
}
/* invert the close button color for darkmode */
.transparency-dark .btn-close  {
  filter: invert(1) grayscale(100%) brightness(200%);
}

</style>