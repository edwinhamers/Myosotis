<script setup>

// IMPORTS
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'

// CONSTS
const { t } = useI18n() // use as global scope

// PROPS
const props = defineProps({
	align: {
		type: String
	},
	bodyMode: {
		type: String
	},
	border: {
		type: Boolean,
		default: false
	},
	borderless: {
		type: Boolean,
		default: false
	},
	borderVariant: {
		type: [String, Array, Object]
	},
	fields: {
		type: [Array],
	},
	fixed: {
		type:Boolean,
		default: false
	},
	footerMode: {
		type: String,
	},
	headerMode: {
		type: String,
	},
	headerVariant: {
		type: String,
	},
	hover: {
		type: Boolean,
		default: false
	},
	items: {
		type: [Array],
		required: true
	},
	responsive: {
		type: Boolean,
		default: false
	},
	smallTable: {
		type: Boolean,
		default: false
	},
	stickyHeader: {
		type: String,
		default: "300px"
	},
	striped: {
		type: Boolean,
		default: false
	},
	tableMode: {
		type: String,
	},
	tableVariant: {
		type: String,
	},
	title: {
		type: String,
		default: "tables.defaults.title"
	}
})


// COMPUTED's ##############################################


// COMPUTED PROPS ##############################



// Props ==> Bootstrap Class Translations ##########################

// Translate Alert Variant to Bootstrap language

const setAlign = computed(() => {
  if(props.align)
		return 'align-' + props.align
})
const setBodyMode = computed(() => {
  if(props.bodyMode)
		return 'table-' + props.bodyMode
})
const setBorder = computed(() => {
  if(props.border)
		return 'table-bordered'
})
const setBorderless = computed(() => {
  if(props.borderless)
		return 'table-borderless'
})
const setBorderVariant = computed(() => {
  if(props.borderVariant)
		return 'border-' + props.borderVariant
})
const setFixed = computed(() => {
  if(props.fixed)
		return 'table-fixed'
})
const setFooterMode = computed(() => {
  if(props.footerMode)
		return 'table-' + props.footerMode
})
const setHeaderMode = computed(() => {
  if(props.headerMode)
		return 'table-' + props.headerMode
})
const setHeaderVariant = computed(() => {
  if(props.headerVariant)
		return 'table-' + props.headerVariant
})
const setHover = computed(() => {
  if(props.hover)
		return 'table-hover'
})
const setResponsive = computed(() => {
  if(props.responsive)
		return 'table-responsive'
})
const setSmallTable = computed(() => {
  if(props.smallTable)
		return 'table-sm'
})
const setStriped = computed(() => {
  if(props.striped)
		return 'table-striped'
})
const setTableMode = computed(() => {
  if(props.tableMode)
		return 'table-' + props.tableMode
})
const setTableVariant = computed(() => {
  if(props.tableVariant)
		return 'table-' + props.tableVariant
})

const setStickyHeader = computed(() => {
	if(typeof props.stickyHeader == 'boolean')
		if (props.stickyHeader)
			return 'table-sticky-header'
	// stickyHeader definition includes height
	return 'table-sticky-header'
})

// END of Computeds

// FUNCTIONS (aka vue2 methods) ##################################


// EMITS ########################################################

</script>

<template>
	<div class="" :class="setResponsive, setStickyHeader">
		<table class="table" :class="setTableMode, setTableVariant, setStriped, setHover, setFixed, setBorder, setBorderless, setBorderVariant, setSmallTable, setAlign">
			<thead class="" :class="setHeaderMode, setHeaderVariant">
			<tr v-if="fields">
				<th v-for="field in fields" scope="col">{{ field.label ? field.label: field.key }}</th>
			</tr>
			</thead>
			<tbody class="" :class="setBodyMode" >
				
				<tr >
					<th scope="row"></th>
					<td v-for="(key, value) in items">{{ key }} {{ value.first_name }}</td>
				</tr>
				<tr >
					<th scope="row"></th>
					<td v-for="(key, value) in items">{{ key }} {{ value.first_name }}</td>
				</tr>
				<tr >
					<th scope="row"></th>
					<td v-for="(key, value) in items">{{ key }} {{ value.first_name }}</td>
				</tr>
			</tbody>
			<tfoot class="" :class="setFooterMode">
				<tr>
					<th v-for="field in fields" scope="col">{{ field.label }}</th>
				</tr>
			</tfoot>
		</table>
	
		
</div>
	
</template>

<style scoped>
.table-fixed {
	table-layout: fixed;
}

.table-sticky-header {
    overflow-y: auto;
    max-height: v-bind(stickyHeader);
}
.table-sticky-header, .table-responsive, [class*=table-responsive-] {
    margin-bottom: 1rem;
}

@supports (position: sticky) {
    /* Positioning of sticky headers */
    .table-sticky-header > .table > thead > tr > th {
      /* Header cells need to be sticky on top */
      position: sticky;
      top: 0;
      z-index: 2;
    }

    /* Positioning of sticky columns
    // Sticky columns only work when table has sticky
    // headers and/or is responsive
		*/
    .table-sticky-header,
    .table-responsive,
    [class*="table-responsive-"] {
      > .table.b-table {
        > thead,
        > tbody,
        > tfoot {
          > tr > .table-sticky-column {
            position: sticky;
            left: 0;
          }
        }

        > thead {
          > tr > .table-sticky-column {
            /* z-index needs to be higher than sticky columns and
            // sticky headers for correct layering */
            z-index: 5;
          }
        }

        > tbody,
        > tfoot {
          > tr > .table-sticky-column {
            /* z-index needs to be lower than sticky header that
            // is also a sticky column */
            z-index: 2;
          }
        }
      }
    }
	}		

</style>