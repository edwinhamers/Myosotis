<script setup>

// IMPORTS ##################################################
import { ref, computed, watch, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'

// CONSTS ####################################################
const { t } = useI18n() // use as global scope


// PROPS ####################################################
const props = defineProps({
  ariaLabelHeaderIconEnd: {
    type: String,
    default: 'header icon end'
  },
  cardClass: {
    type: [String,Array,Object],
  },
  cardVariant: {
    type: String,
  },
  footer: {
    type: String
  },
  footerClass: {
    type: [String,Array,Object],
  },
  footerTag: {
    type: String,
    default: "div"
  },
  footerTagClass: {
    type: [String,Array,Object],
  },
  headerBgVariant: {
		type: String,
	},
	headerClass: {
		type: [String,Array,Object],
	},
  headerClientGenderIcon: {
		type: Object,
	},
	headerClientBirthdate: {
		type: String,
	},
	headerClientBirthdateIcon: {
		type: Object,
	},
	headerClientName: {
		type: String,
		default: '' 	// default is required for the t() function as it needs a parameter
	},
	headerIcon: {
		type: Object,
	},
  headerIconEnd: {
		type:Object
	},
  headerIconEndClass: {
    type: [String, Array, Object],

  },
	headerTitle: {
		type: String,
		default: 'cards.defaults.header_title' 	// default is required for the t() function as it needs a parameter
	},
  headerTitleClass: {
		type: [String, Array, Object],
    default: "m-1"
	},
	headerTitleTag: {
		type: String,
		default: "h1"
	},
  id: {
    type: String,
    required: true
  },
  title: {
    type: String,
    default: "cards.defaults.title"
  },
  titleClass: {
    type: [String, Array, Object],
  },
  titleTag: {
    type: String,
    default: 'div'
  },
  subTitle: {
		type: String,
	},
  subTitleClass: {
    type: [String, Array, Object],
  },
	subTitleTag: {
		type: String,
		default: 'div'
	}
  
})

// COMPUTED ######################################################
// Set background variant
const setBackgroundVariant = computed(() => {
	if(props.headerBgVariant) {
		return 'bg-' + props.headerBgVariant
	} 
})

// Set the color mode on the close button 
// -> btn-close-white has been deprecated in bootstrap 5.3.0 
//
// We match 'warning', 'info' and 'light' and display the close button in black (=light mode)
// Any 'subtle' variant will be displayed in black (=light mode)
// all other matches are displayed in white (=dark mode)

const setColorModeCloseButton = computed(() => {
		const warningrgex = /warning(.*)/g;
		const inforgex = /info(.*)/g;
		const lightrgex = /light(.*)/g;
		const subtlergex= /\bsubtle\b/g;
		
		if (!props.headerBgVariant) 
				return ''
		if (props.headerBgVariant.match(subtlergex) 
				|| props.headerBgVariant.match(warningrgex)  
				|| props.headerBgVariant.match(inforgex) 
				|| props.headerBgVariant.match(lightrgex) 
		) 
				return 'light'
		return 'dark'
})

// Translate & Set Text variant
const setCardVariant = computed(() => {
	if(props.cardVariant) {
		return 'text-bg-' + props.cardVariant
	} 
})

// Translate & Set Text variant
const setTextVariant = computed(() => {
	if(props.headerBgVariant) {
		return 'text-bg-' + props.headerBgVariant
	} 
})

// EMITS ########################################################
// Define emits functions - REQUIRED
const emit = defineEmits(['headericonend', ])

// emit header icon end event (modal is automatically closed by bootstrap)
const emitHeaderIconEnd = function() {
	emit('headericonend', 'headericonend')
}

// WATCHERS ######################################################


// FUNCTIONS (aka vue2 methods) ##################################



// ONMOUNTED (not reactive) #################################

onMounted(() => {
// Content coming soon :-)
})

</script>

<template>

<div 
  :id="id" 
  class="card" 
  :class="cardClass, setCardVariant"
>
  <div class="card-header d-flex" :class="setBackgroundVariant, setTextVariant, headerClass">
    <component :is="headerTitleTag" class="fs-5 flex-fill" :class="headerTitleClass">
      <fa v-if="headerIcon" :icon="[headerIcon.style,headerIcon.name]" class="mr-1" />
      {{ t(props.headerTitle) }}
      <fa v-if="headerClientGenderIcon" :icon="[headerClientGenderIcon.style,headerClientGenderIcon.name]" class="mx-1" />
      {{ props.headerClientName }}
      <fa v-if="headerClientBirthdateIcon" :icon="[headerClientBirthdateIcon.style,headerClientBirthdateIcon.name]" class="mx-1" />
      {{ props.headerClientBirthdate }}
    </component>
    <div :data-bs-theme="setColorModeCloseButton" class="" :class="headerTitleClass, headerIconEndClass">
      <fa
        v-if="props.headerIconEnd"
        :icon="[headerIconEnd.style,headerIconEnd.name]" 
        :aria-label="props.ariaLabelHeaderIconEnd"
        @click="emitHeaderIconEnd"/>
    </div>
  </div>

  <div class="card-body">
    
    <component 
      v-if="title" 
      :is="titleTag" 
      class="card-title" 
      :class="titleClass"
    >
      {{ t(props.title) }}
    </component>
    
    <component 
      v-if="subTitle" 
      :is="subTitleTag" 
      class="card-subtitle" 
      :class="subTitleClass">
      {{ t(props.subTitle) }}
    </component>
    <p class="card-text">
      <slot></slot>
    </p>
  </div>
  <div v-if="footer" class="card-footer" :class="footerClass">
    <component :is="footerTag" class="" :class="footerTagClass">
      {{ props.footer }}
    </component>
    
  </div>

  
</div>

</template>

<style scoped>


</style>