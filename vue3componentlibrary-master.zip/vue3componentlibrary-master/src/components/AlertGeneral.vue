<script setup>

// IMPORTS ##################################################
import { ref, computed, watch, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'

// CONSTS ####################################################
const { t } = useI18n() // use as global scope


// PROPS ####################################################
const props = defineProps({
  ariaLabelDismiss: {
    type: String,
    default: 'Close'
  },
  class: {
    type: [String, Array, Object]
  },
  closeVariant: {
    type: String,
    default: "dark"
  },
  dismissible: {
    type: Boolean,
    default: false
  },
  fade: {
    type: Boolean,
    default: true
  },
  headerClass: {
    type: [String, Array, Object]
  },
  id: {
    type: String,
    required: true
  },
  show: {
    type: Boolean,
    default: false
  },
  title: {
		type: String,
		default: 'alerts.defaults.title' 	// default is required for the t() function as it needs a parameter
	},
  titleBadge: {
    type: Boolean,
    default: true
  },
  titleBadgeClass: {
    type: [String, Array, Object],
    default: "p-2 me-2"
  },
  titleBadgeVariant: {
    type: String,
    default: 'info'
  },
  titleClass: {
    type: [String, Array, Object],
    default: 'me-auto'
  },
  titleIcon: {
		type: Object,
	},
  titleIconClass: {
    type: String,
    default: 'me-2'
  },
  titleTag: {
    type: String,
    default: 'div'
  },
  variant: {
    type: String,
    default: 'primary'
  },
  
})

// COMPUTED ######################################################

// Bootstrap translations
const setCloseVariant = computed(() => {
	if(props.closeVariant === 'light') {
		return 'btn-close-white'
	} 
})
const setVariant = computed(() => {
	if(props.variant) {
		return 'alert-' + props.variant
	} 
})

const setDismissible = computed(() => {
	if(props.dismissible) {
		return 'alert-dismissible'
	} 
})
const setFade = computed(() => {
	if(props.fade) {
		return 'fade'
	} 
})
const setShow = computed(() => {
	if(props.show) {
		return 'show'
	} 
})

const setHeaderVariant = computed(() => {
	if(props.headerVariant) {
		return 'text-bg-' + props.headerVariant
	} 
})
const setTitleBadgeVariant = computed(() => {
	if(props.titleBadgeVariant) {
		return 'text-bg-' + props.titleBadgeVariant
	} 
})

// WATCHERS ######################################################


// FUNCTIONS (aka vue2 methods) ##################################



// ONMOUNTED (not reactive) #################################

onMounted(() => {
  const alertPlaceholder = document.getElementById('liveAlertPlaceholder')
const appendAlert = (message, type) => {
  const wrapper = document.createElement('div')
  wrapper.innerHTML = [
    `<div class="alert alert-${type} alert-dismissible" role="alert">`,
    `   <div>${message}</div>`,
    '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
    '</div>'
  ].join('')

  alertPlaceholder.append(wrapper)
}

const alertTrigger = document.getElementById('liveAlertBtn')
if (alertTrigger) {
  alertTrigger.addEventListener('click', () => {
    appendAlert('Nice, you triggered this alert message!', 'success')
  })
}
})

</script>

<template>

<div 
  class="alert" 
  :class="props.class, setShow, setVariant, setFade, setDismissible"
  role="alert"
>
  <div class="toast-header" :class="headerClass">
    <div v-if="!titleIcon && titleBadge" class="" :class="setTitleBadgeVariant, titleBadgeClass">
    </div>
    <fa v-if="titleIcon" :icon="[titleIcon.style,titleIcon.name]" :class="titleIconClass" />
    
    <component :is="titleTag" class="" :class="titleClass">
      {{ t(title) }}
    </component>
    <button
      v-if="dismissible"
      type="button" 
      class="btn-close" 
      :class="setCloseVariant" 
      data-bs-dismiss="alert" 
      :aria-label="props.ariaLabelDismiss">
    </button>
  </div>
  <div class="toast-body">
    <slot></slot>
  </div>


  

</div>

</template>

<style scoped>

</style>