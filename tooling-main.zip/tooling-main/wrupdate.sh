#!/bin/bash

################################################################3333
# WebRaap Update script
# Updating WebRaap (WR4 and higher)
#
# Usage
# wrupdate.sh
#
# Arguments: 
# See usage() function
#
#*****************************************************************
# Configuration
#
# Add your configuration to wrupdate.conf
#
# >>>> WARNING: DO NOT CHANGE ANY VARIABLES/VALUES. <<<<
# >>>> ANOTHER WARNING: DO NOT CHANGE ANY VARIABLES/VALUES. <<<<
# >>>> LAST WARNING: DO NOT CHANGE ANY VARIABLES/VALUES. <<<<

#*****************************************************************
# DO NOT CHANGE ANYTHING BELOW THIS LINE
#*****************************************************************

#*****************************************************************
# SYSTEM CONFIG VARIABLES AND GLOBALS

#----------------------------------------------------------
# Script version
version="2.8";

#----------------------------------------------------------
# Regular expressions
# Used in various if [ ] tests

# Define integer regex
# Bash does not use 'integers'. All variables are string characters
is_integer='^[0-9]+$'

#----------------------------------------------------------
# Default values
#
# The variables below are set as defaults when they are
# not (yet) set in wrupdate.conf.
# These variables will be overwritten when importing the config file
#----------------------------------------------------------

# Run level
# Value: true/false
# Can be enabled using script arguments
dry_run=false;

# Version check. Default false
run_version_check="false"

# log level 
# values: trace, debug, info, notice (verbose), warning, error, fatal
# default: warning
# Can be set with the log level argument
log_level="warning"

# Log route
# default set to 'screen'
# Do NOT change this value. Use wrupdate.conf
log_route="screen"

# Constant name in wr-config.php (WR4.x install) for WR5 feature branch
# See function checkWhichBranch()
wrn_active_search_string="define('WRN_ACTIVE', 'true');"
wrn_active_search_string_variation="define('WRN_ACTIVE', '1');"

# Branching options

# Default value for Select branch 
select_branch=false

# default main/master branch name
default_branch="master"

# Default branch name
active_branch=$default_branch

# Default feature branch for WR4
feature_branch_wr4="fb_SSO_from_WRN"

# Default configuration filename
config_file="wrupdate.conf"
config_file_sample="wrupdate.conf-sample"
repo_wrupdate_folder_name="tooling.git"

# User EPD Api 
userepd_api=false

# Database defaults
backup_path=false
db_backup_before_migrate=false
compress_backup=false
db_user_global_enable="false"

# Forcing db:migrate option
# Override with commandline option
force_dbmigrate=false

# No domain selected default
# See function appSelect/appUpdate
no_domain_selected=false

# Sudo prompt
# Used in dbBackup()
export SUDO_PROMPT="Enter sudo password: "

#*****************************************************************
# SYSTEM CONFIG VARIABLES AND GLOBALS
#
# DO NOT CHANGE ANYTHING IN THIS SECTION!!!
#
#*****************************************************************

# Log level array
# log level MUST match the log level color definition array logColors[]
declare -A logLevels
logLevels[trace]=0
logLevels[debug]=1
logLevels[info]=2
logLevels[notice]=3
logLevels[warning]=4
logLevels[error]=5
logLevels[fatal]=6


#*****************************************************************

#*****************************************************************
# INITIALISE - Phase 1
#*****************************************************************

#*****************************************************************
#  Locate and set script name and paths to read the config file
# 
# NOTE: We cannot use standard functions because they are not loaded yet

# The script can be started from any location (if in $PATH) or by calling
# the script root path
# In both case we need to load the config file

current_path=`pwd`
script_name=`basename "$0"` # path used to execute this script
script_path=`dirname "$0"` # is empty when executed from .
self_path="${0}" #Path and script that was executed

# When this script is installed in the local PATH and executed without
# specifying a path, the $PATH environment variable is used to locate the script
script_env_path=`which wrupdate.sh`

# Set datetime when this script started
datetime_start=$(date +"%Y-%m-%d_%I_%M_%p")

#*****************************************************************

#----------------------------------------------------------
# Color Variables
# These color variables are used in the color functions
# Note: when adding a new color also create the color function below
# Bash color generator: https://robotmoon.com/bash-prompt-generator/
# See also: https://stackoverflow.com/a/4332530
#----------------------------------------------------------
colorgreen='\e[1;32m'
colorblue='\e[1;34m'
colorblue='\033[1;34m'
colorred='\e[1;31m'
coloryellow='\e[1;33m'
colororange='\033[1;31m'

# Array with log level color definitions
# See function log()
declare -A logColors
logColors["fatal"]='\e[38;5;196m' # Red
logColors["error"]='\e[38;5;160m' # Red
logColors["warning"]='\e[38;5;208m' # orange
logColors["notice"]='\e[38;5;11m' # yellow
logColors["info"]='\e[38;5;15m' #white
logColors["debug"]='\e[38;5;248m' #gray
logColors["trace"]='\e[38;5;248m' # Gray
logColors["reset"]='\033[0m'    # Reset color



# echo -e ${logColors['fatal']}"A fatal message"${logColors['reset']}
# echo -e ${logColors['error']}"A error message"${logColors['reset']}
# echo -e ${logColors['warning']}"A warning message"${logColors['reset']}
# echo -e ${logColors['notice']}"A notice message"${logColors['reset']}
# echo -e ${logColors['info']}"An info message"${logColors['reset']}
# echo -e ${logColors['debug']}"A debug message"${logColors['reset']}
# echo -e ${logColors['trace']}"A trace message"${logColors['reset']}
# exit 1

# Reset color
colorclear='\e[0m'

#-----------------------------------------------
# Color Functions
##

colorGreen(){
	echo -e $colorgreen$1$colorclear
}
colorBlue(){
	echo -e $colorblue$1$colorclear
}
colorRed(){
	echo -e $colorred$1$colorclear
}
colorYellow(){
	echo -e $coloryellow$1$colorclear
}
colorOrange(){
	echo -e $colororange$1$colorclear
}


#*****************************************************************
# HELP PAGE 
#*****************************************************************
function usage() {
  echo "Usage: "$0" [options]"
  echo ""
  echo "Options:"
  echo ""
  echo " -b     force feature branch selection"
  echo " -h     show this help"
  echo " -f     enable db:migrate option. BE CAREFULL!"
  echo " -t     Enable db tools menu"
  echo " -u     update wrupdate.sh from git repo"
  echo " -v     Show version of script and config"
  echo ""
  echo "Long options:"
  echo ""
  echo " --db   create a database backup before any migrate"
  echo " --dry   Do a dry run without changing data"
  echo " --loglevel possible values: trace, debug, info, notice, warning, error, fatal"
  echo " For example 'wrupdate.sh --warning'"
}



#*****************************************************************
# COMMAND LINE OPTIONS 
#*****************************************************************

#
options=$(getopt -o 'bftuvh' --long 'db,dry,trace,,debug,info,notice,warning,error,fatal' -n "$0" -- "$@")
if [ $? -ne 0 ]; then
    # if getopt returns a non-zero status there was an error
    usage
    exit 1
fi

# eval the options
eval set -- "$options"
unset options

# Process the parsed options and arguments
while true; do
   case "$1" in
       '-b')
           select_branch=true
           shift
           continue
       ;;
       '-f')
           force_dbmigrate=true
           shift
           continue
       ;;
       '-t')
           enable_dbtools=true
           shift
           continue
       ;;
       '-u')
           update_self=true
           shift
           continue
       ;;
       '-v')
           run_version_check="true" 
           shift
           continue 
       ;;
       '-h')
           usage
           exit 1
       ;;
       '--')
           shift
           break
       ;;
       '--db')
           db_backup_before_migrate_cmdline="true"
           shift
           continue
       ;;
       '--dry')
           dry_run="true"
           shift
           continue
       ;;
       '--trace')
           user_log_level="trace"
           shift
           continue
       ;;
       '--debug')
           user_log_level="debug"
           shift
           continue
       ;;
       '--info')
           user_log_level="info"
           shift
           continue
       ;;
       '--notice')
           user_log_level="notice"
           shift
           continue
       ;;
       '--warning')
           user_log_level="warning"
           shift
           continue
       ;;
       '--error')
           user_log_level="error"
           shift
           continue
       ;;
       '--fatal')
           user_log_level="fatal"
           shift
           continue
       ;;
      *)
       echo 'No valid options or arguments supplied. Ignoring all options and using default configuration' >&2
       break 
      ;;
   esac
done

#*****************************************************************
# GLOBAL FUNCTIONS 
#
# Global functions that should be available before other functions
# should be placed here...
#*****************************************************************


#----------------------------------------------------------------
# logFileCheck()
# The available log routes are: screen, file
#
# Usage: logFileCheck <log_route> <log_path> <current path>
#
# Global arguments
# log_file_name_path
#
# Returns (global)
# log_file_name_path: full path and filename to log file

function logFileCheck() {

   # Read arguments
   #echo "Started function logFileCheck: logFileCheck arguments are: $@"
   local log_route_local="$1"
   local log_path_local="$2"
   local current_path_local="$3"

    # log file name
   local datetime_prefix=$(date +"%Y-%m-%d")
   local log_filename="wrupdate-$datetime_prefix.log"


      if [[ "$log_route_local" == "file" ]]; then
         #echo "Log route was set as argument to: $log_route_local"

         # Check if log_path is set to empty or its default
         if [[ -z "$log_path_local"  || "$log_path_local" =~ "_DEFAULT" ]]; then
            #echo "log path has not been set or set to default. Using current path"
            # log path has not been set or set to default. Using current path
            log_file_name_path="$current_path_local/$log_filename"
            # Test if log file already exists
            if [[ ! -w "$log_file_name_path" ]]; then
                #echo " Creating log file: $log_file_name_path"
                # Creating log file
               touch "$log_file_name_path"
            fi
            echo "Logging is enabled. Log file is: $log_file_name_path"
            echo "**********************************************************" >>"$log_file_name_path"
            echo "* Log started: $datetime_start." >>"$log_file_name_path" >>"$log_file_name_path"
            echo "* Default log level: $log_level. User log level: $user_log_level" >>"$log_file_name_path"
            if [[ "$log_level" != "info" ]]; then
               echo "Set log level to 'info' to view default messages in this log file" >>"$log_file_name_path"
            fi 
            echo "**********************************************************" >>"$log_file_name_path"
         else
            #echo "Log path was already set to: $log_path_local. Using that"
            # Log path has been set. Check for availability and writability
            if [[ -d "$log_path_local" && -w "$log_path_local" ]]; then
               #echo "Log path is writable for $log_path_local"
               # log path exists and is writable
               log_file_name_path="$log_path_local/$log_filename"
               if [[ ! -w "$log_file_name_path" ]]; then
                   # Creating log file
                  touch "$log_file_name_path"
               fi
               echo "Logging is enabled. Log file is: $log_file_name_path"
               echo "**********************************************************" >>"$log_file_name_path"
               echo "* Log started: $datetime_start." >>"$log_file_name_path" >>"$log_file_name_path"
               echo "* Default log level: $log_level. User log level: $user_log_level" >>"$log_file_name_path"
               if [[ "$log_level" != "info" ]]; then
                  echo "Set log level to 'info' to view default messages in this log file" >>"$log_file_name_path"
               fi 
               echo "**********************************************************" >>"$log_file_name_path"
            else
               #echo "Log path is NOT writable for $log_path_local"
               # log path does not exists or is not writable
               colorOrange "Warning: The log path ($log_path), set in wrupdate.conf, does not exists or is not writable. Logging to file is disabled"
               # Reset log file name and path to override setting in wrupdate.conf that is not correct
               log_file_name_path=""
            fi
         fi # END of if log_path
      fi # END of if log_route=file

} # END of function


#----------------------------------------------------------------
# log()
# Function that logs to a configured log route
# The available log route are: screen, file
#
# Usage: log <log level> <message>
# 
# Log levels
# 0 - trace:  Increasing level of details
# 1 - debug:  Debugging messages
# 2 - info:   Informational messages
# 3 - notice:  (verbose), ormal, but significant conditions
# 4 - warn:   Warning conditions
# 5 - error:  Error conditions
# 6 - fatal:  Fatal conditions
# 
# Global arguments
# -_log_level
# - user_log_level (cmd line argument)
# - log_color
# - log_route
# - log filename and path (log_file_name_path)


function log() {

   # Read arguments
   #Not logging the log function :-p
   #echo "Arguments fo log(): $@"
   #echo "Globals are: user log level: $user_log_level, log route: $log_route, log file: $log_file_name_path"
   local log_level_arg="$1"
   shift 1
   local log_message="$@"
   local log_route_local="$log_route"

   if [ -z "$log_level_arg" ] || [ -z "$log_message" ]; then
       # Cannot use the log function within itself
       colorRed "Fatal: Incorrect arguments for function log(): $log_level_arg, $log_message, $@";
       exit 1;
   fi

   # Is log level set by user (via command line) ?
   if [[ -n "$user_log_level" ]]; then
       log_level="$user_log_level"
   fi

    # Check if level exists
    # See https://stackoverflow.com/q/48086633 for the magic
    # not sure how the 'return 1 and return 2' actually work
    [[ ${logLevels[$log_level_arg]} ]] || return 1

    #check if level is enough
    (( ${logLevels[$log_level_arg]} < ${logLevels[$log_level]} )) && return 2

    #log here
    local logcolor=${logColors[$log_level_arg]}
    if [[ "$log_route_local" == "file" && "$log_file_name_path" ]]; then
      echo -e $logcolor"${log_level_arg} : ${log_message}"${logColors["reset"]} >>"$log_file_name_path"
    else
      echo -e $logcolor"${log_level_arg} : ${log_message}"${logColors["reset"]}
    fi
    #echo -e $logcolor"${log_level_arg} : ${log_message}"${logColors["reset"]}

    # Exit app when log level is 'error' or 'fatal'
    if [[ "$log_level_arg" == "error" || "$log_level_arg" == "fatal" ]]; then
      if [[ "$log_route_local" == "file" ]]; then
         echo -e $logcolor"${log_level_arg} error occured. Exiting program..."${logColors["reset"]} >>"$log_file_name_path"
      else
         echo -e $logcolor"${log_level_arg} error occured. Exiting program..."${logColors["reset"]}
      fi
      exit 1
    fi


} # END of function


#----------------------------------------------------------------
# pause()
# Pause the script until user presses any key
#
# Usage: pause <message>
#
# Arguments
# - Message to display for user before pressing any key

function pause() {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # Read test to display
   local message="$1"

   read -rsp $"$message" -n1 key

} # END of function

#-----------------------------------------------------------------------
# listDomains()
# display a list of domains from array domainPathArray
#
# Usage: listDomains <domain array>
#
# Arguments
# - array with domain list

function listDomains() {
   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # Reset PS3
   # Settings colors in PS3 does not work like PS1/PS2 !! Bug/feature!
   PS3=$'\e[01;33mChoose app domain (q=exit menu ,l=list apps): \e[0m'

   # read array with domain paths
   local domain_path_array=("$@");
      ITER=1
      for appdomain in "${domain_path_array[@]}"
      do
        echo "$ITER) $appdomain";
       ((ITER++)) # Increment iteration counter
      done
}
# END of function

#*****************************************************************
# HOUSEKEEPING & INITIALISE - Phase 2
# See below for main application start
# NOTE: We cannot use standard functions because they are not loaded yet
#*****************************************************************

#*****************************************************************
#  Locate and set script name and paths to read the config file
# 
# NOTE: We cannot use standard functions because they are not loaded yet

# The script can be started from any location (if in $PATH) or by calling
# the script root path
# In both case we need to load the config file

# TODO: When wrupdate.sh is available in $PATH it needs to be checked when reading
#       the config file......

# Find the current path, scriptname and dirname
log debug "Initialising application. Setting up paths"
log debug "Script paths has been set to"
log debug "Current path: $current_path"
log debug "Script name: $script_name"
log debug "Script path: $script_path"
log debug "Script env path: $script_env_path"
log debug "Self path: $self_path"


# ----------------------------------------------
# Reading config file
if [[ -r "$script_path/$config_file" ]]; then
    # Found config file 
    log notice "-- Found readable config file in ($script_path/$config_file). Importing..."

# ----------------------------------------------
    # import the config file
    source "$script_path/$config_file";

# ----------------------------------------------
    # Check for default values in config file (user did not add customizations)
    if [[ "$wrupdate_path" =~ "_DEFAULT" ]]; then
      # User did not change default values. exit
      log warning "The wrupdate_path has not been set in $config_file"
      log error "-> Add your custom values to  $config_file and restart..."
      exit 0
    fi

# ----------------------------------------------
# Version check
# Check if the version of wrupdate.sh and wrupdate.conf match
   # Run version check if requested by user
   if [[ "$run_version_check" == "false" ]]; then
      log debug "Running version check for script and config"
      log debug "Checking if script and config version are matching";
      if [[ "$version" == "$config_version" ]]; then
         #  Versions are matching
         log notice "-- Config version and application version are matching";
      else
         log warning "The wrupdate.sh ($version) and wrupdate.conf ($config_version) version are not matching!";
         log fatal "-> Update wrupdate.sh and wrupdate.conf to the latest release."
         exit 0
      fi
  else
      echo "Script version: $version"
      echo "Config version: $config_version"
      exit 1
  fi


# ----------------------------------------------
    # Check if domains were added
    if [[ "${domainPathArray[0]}" == "LOCAL_PATH_TO_APP_ROOT_FOLDER1" ]]; then
      # User did not change default values. exit
      echo -e $red"Error: Default value found for domainPathArray. No domains were added to the config!$colorclear";
      echo -e $yellow"Info:$colorclear Add your custom domains to  $config_file and restart..."
      exit 0
    fi

# ----------------------------------------------
    # Check for wrupdate repo folder name default
    if [[ "$repo_wrupdate_folder_name" == "FOLDER_NAME_WRUPDATE_REPO" ]]; then
      # User did not change default values. exit
      echo -e $red"Error: Default value found for variable 'repo_wrupdate_folder_name' in the config file!$colorclear";
      echo -e $yellow"Info:$colorclear Add your custom value to $config_file and restart..."
      exit 0
  else
      # Check if user, accidentally, added a path and name
      if [[ "$repo_wrupdate_folder_name" == *\/* ]] || [[ "$repo_wrupdate_folder_name" == *\\* ]]; then
         echo -e $red"Error: The config value contains a path instead of just the folder name!$colorclear";
         echo -e $yellow"Info:$colorclear Remove the path from the folder name."
         exit 0
      fi

    fi

# ----------------------------------------------
# Check if Path to Git Repos exists
#if [ -d "$repospath" ] && [ -r "$repospath" ]; then
if [[ -r "$reposPath" && -d "$reposPath" ]]; then
   if [[ verbose == "true" ]]; then
       echo "-- Path to git repositories ($reposPath) is found and is readable"
   fi
else
    echo -e ${logColors["fatal"]}"Fatal: Git repos folder not found at $reposPath"${logColors["reset"]}
    echo -e ${logColors["notice"]}"Add the correct path to the wrupdate repository..."${logColors["reset"]}
    exit 0
fi

# ----------------------------------------------
    # Check database backup path
    # Disable backups by default until checks are validated
    enable_backups="false"
    if [[ debug == "true" ]]; then
        echo -e $yellow"-- Backup configuration checks"$colorclear
        echo "--- Backups are disabled until config checks are passed"
    fi

    # First check if backup_path exists in wrupdate.conf
    if [[ "$backup_path" == "false" ]]; then
        echo -e $orange"Warning: No backup path was found in wrupdate.conf. Backups are disabled!$colorclear"
        echo -e $yellow"Info:$colorclear Are you using the latest version?"
    else
    if [[ debug == "true" ]]; then
        echo "--- backup_path was found: $backup_path"
    fi

    # Now check if default value was used for backup path
    if [[ "$backup_path" == "BACKUP_PATH_DEFAULT" ]]; then
        # User did not set a backup path
        echo -e $orange"Warning: Default backup path found. Backups are disabled!$colorclear"
        echo -e $yellow"Info:$colorclear Change the backup_path value in wrupdate.conf."
    else
        if [[ debug == "true" ]]; then
            echo "--- Backup path is not set to default value."
        fi
        # Check if backup path is an existing directory
        if [ ! -d "$backup_path" ]; then
            echo -e $orange"Warning: database backup path ($backup_path) does not exist! Backups are disabled.$colorclear"
            echo -e $yellow"Info:$colorclear Add an existing directory to $config_file."
        else
            # backup path exists. Check for write access
            if [[ debug == "true" ]]; then
               echo "--- Backup path exists on filesystem"
            fi
            if [ ! -w "$backup_path" ]; then
               echo -e $orange"Error: database backup path ($backup_path) is not writable! Backups are disabled.$colorclear"
               echo -e $yellow"Info:$colorclear Add write permission to $backup_path."
            else
               if [[ debug == "true" ]]; then
                  echo "--- Backup path is writable."
                  echo "--- Enabling backups."
               fi
                # All checks are validated. Enable backups
                enable_backups="true"
            fi
        fi
    fi
    fi # End of if backup_path exists in wrupdate.conf

    if [[ "$enable_backups" == "true" ]]; then
      log notice "Database backups are enabled"
    fi


# ----------------------------------------------
# Check if global database user is set
   log debug "Checking if global database user has been set by user"
   if [[ -z "$db_user_global" ]] || [[ "$db_user_global" =~ "_DEFAULT" ]]; then
      log warning "Global database user is not set. Change db_user_global in wrupdate.conf"
   else
      log debug "-- Global database user (db_user_global) has been set to $db_user_global"
       db_user_global_enable="true" 
   fi


# ----------------------------------------------
    # Check wr5 database variable definition array for default values
    # See https://www.baeldung.com/linux/check-bash-array-contains-value
    if [[ ${wr5DbDefArray[@]} =~ "_DEFAULT" ]]; then
        echo -e $red"Error: There are _DEFAULT values found in the database variable definitions...$colorclear"
        echo -e $yellow"Info:$colorclear Add your custom database variable definitions to the $config_file";
        echo -e $yellow"Info:$colorclear Database backups are disabled..."
        enable_backups="false"
    fi

# ----------------------------------------------
    # Check wr4 database variable definition array for default values
    # See https://www.baeldung.com/linux/check-bash-array-contains-value
    if [[ ${wr4DbDefArray[@]} =~ "_DEFAULT" ]]; then
        echo -e $red"Error: There are _DEFAULT values found in the database variable definitions...$colorclear"
        echo -e $yellow"Info:$colorclear Add your custom database variable definitions to the $config_file";
        exit 0
    fi

# ----------------------------------------------
# Set up logging
# This will create the log file, if it was not already created before
logFileCheck "$log_route" "$log_path" "$current_path"


# ----------------------------------------------
# ----------------------------------------------
# All config checks are passed.
   log notice "Config file ($config_file) was imported and checked!";

# Config file was not found ----------------------------------
else
    if [[ -e "$script_path/$config_file_sample" ]]; then
      echo -e $red"Fatal: Config file ($config_file) not found in $script_path$colorclear";
      echo -e $yellow"Info:$colorclear Rename the sample config ($file_config_sample) file, adjust permissions and restart..."
      exit 0
    else
      echo -e $red"Fatal: Sample Config file ($config_file_sample) not found in $script_path$colorclear";
      echo -e $yellow"Info:$colorclear Reinstall the script and sample configuration";
      exit 0
    fi
fi # END of reading config file check

   
#*****************************************************************
# DEFAULT VALUES LOADER
# Load changes to default values from the config file

#-----------------------------------------------------------------
# User EPD API rebuild
# Default: false (see above)
# Depending on the value the npm command has to be changed
# Set the correct command for the npm rebuild when using User EPD API
if [ "$userepd_api" == "true" ]; then
   npm_command="npm --section=userepd run prod"
else
  npm_command="npm run prod"
fi 

#-----------------------------------------------------------------
# Check if selecting of branch was forced in config file
# If true then force feature branch selection
# Can also be set using a commandline option
# Default value: false
if [ "$force_select_branch" == "true" ]; then
    select_branch=true
fi

#----------------------------------------------------------------
# initRepos()
# Check available git repos and initialize the array with repo names
# Parameter: PATH to repos (defined as $reposPATH)
# Returns: git repository folder names, separated by spaces $reposNameArray (array)
#
# TODO: Add a check for each folder that is found to make sure it is a git repo!
function initRepos() {

# Logging
log debug "-- Started function ${FUNCNAME[0]} "

# Read repo PATH
local repospath=$1

# Check Script modus. Should be "fetch" for this function.
if [ "$gitmodus" = "fetch" ]; then
   # Git repos folder found. Find git repo folder names
	readarray -t reposNameArray < <(find $repospath -mindepth 1 -maxdepth 1 -type d -printf '%P\n')
   if (( ${#reposNameArray[@]} )); then
     log debug "--- Found ${#reposNameArray[@]} git repositories in $repospath"
     for repo_name in "${reposNameArray[@]}";
     do
       log debug "--- Found repo name: $repo_name";
     done
   else
       log fatal "No git repos found in $repospath";
   fi
else
   log warning "--- Git repository initialisation was not started because the git mode is set to 'pull'. Change to 'fetch' when required."
fi
}
# END of function


#----------------------------------------------------------------
# repoUpdate() - Github Repository Update
# Function that updates the local repository with the latest commits
#
# Parameter (required)
# - Array with Repo PATH'
# - Gitmodus (from configuration variable $gitmodus)

function repoUpdate() {

# Logging
log debug "Started function ${FUNCNAME[0]} "

# Read array
paths=("$@")

# Check git modus
if [ "$gitmodus" == "fetch" ]; then
   if [ -z $paths ]; then
       log warning "No repositories found in $paths to update"
   else
	   for i in "${paths[@]}";
		do
         colorGreen "--- Updating repo ";echo $i
        	cd $reposPath/$i
        	git fetch -p origin
			colorGreen "--- Showing last 3 commits from ";echo $i
			git log -3
		done
   fi
else
   if [ "$gitmodus" == "pull" ]; then
       log info "Git repos cannot be updated when git modus is set to 'pull'. Update each application seperately";
   else
       log error "Updating the git repositories went wrong";
   fi
fi
}
# END of function

#----------------------------------------------------------------
## setAppRepoPath {
# Loops through the Git Repo Array and sets the repo type matching
# the supplied $app_type
#
# Usage
# setAppRepoPath <app type> <repo path> <Domain path array>
#
# Arguments
# <app type>: Application type (webraap4 | webraap5)
# <repo path>: Repository folder (set globally)
# <repo name array>: Repositories name array (set by initRepos) 
#
# Returns
# app_repository_path: PATH to matching git repo (global)
#
# remark: bash functions never return values so we use echo as a 'return value'

function setAppRepoPath {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # Read the arguments
   local app_type=$1 # Read app type
   local repos_path=$2 # Read PATH to repositories
   shift 2 # Shift all arguments to read the array
   repos_array=("$@"); # Read the array

   # Logging
   log notice "App type: $app_type"
   log notice "Repositories path: $repos_path"

   # Loop through repo array and match app_type with repo config name
   # NOTE: The actual GitHub Repository name is used to determine the match.
   # Should be "webraap4" or "Webraap5" !!
   for repo_name in "${repos_array[@]}"
   do
      log notice "Matching ($app_type) with $repos_path/$repo_name/config";
      # Find the app_type in the git/config file. If found echo the matching repo path
      if grep -Fq "$app_type" "$repos_path/$repo_name/config"
      then
         log notice "Found matching repository: $app_type in $repos_path/$repo_name/config"
         # "return" matching repo path in global var
         app_repository_path="$repos_path/$repo_name";
      else
          log notice "setAppRepoType: App type ($app_type) does not match $repos_path/$repo_name/config"
      fi
   done
}
# END of function

#----------------------------------------------------------------
# selectBranch2()
# Show list of available branches and ask user to select
#
# Usage
# selectBranch2() <path git repo> <feature branch prefix> <select branch>
#
# Arguments
# <path to domain>: PATH to git repo
# <feature branch prefix>: Feature branch prefix (global)
# <select branch>: is selecting branch enabled
#
# Output
# $active_branch (global)

function selectBranch2() {
   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   log notice "Active branch is $active_branch (from config)."
   log notice "Default branch is $default_branch"

   # Settings colors in PS3 does not work like PS1/PS2 !! Bug/feature!
   PS3=$'\e[01;33mChoose feature branch (q=exit, <enter>=show list): \e[0m'

   # Read the argument(s)
   local git_repo_path=$1
   local fb_prefix=$2

   # Declarate branches array
   declare -a branchArray

   # List branches and add to array
   cd "$git_repo_path"
   eval "$(git for-each-ref --shell --format='branchArray+=(%(refname))' refs/heads/$fb_prefix)"
   exit_loop=0
   while [ "$exit_loop" -eq 0 ]; do 
   select sel_option in "${branchArray[@]}"; do
      # Check the selected menu item number
      # Check first if user supplied special command instead of selecting
      if [ "$REPLY" == "q" ]; then
         case "$REPLY" in
            q) mainmenu;; 
            *) echo "Unknown option. Choose a domain or command (q=main menu, <enter>=listt)";
            ;;
         esac
      # The user is just selecting a branch
      elif [[ "$REPLY" =~ $is_integer ]] && [ 1 -le "$REPLY" ] && [ "$REPLY" -le ${#branchArray[@]} ]; then
         log notice "Selected branch is: $sel_option"
         # Removing /ref/heads from git for-each-ref output and adding prefix
         stripped_branch_name="$(basename -- $sel_option)"
         active_branch=$fb_prefix$stripped_branch_name
         log debug "Selected branch name is: $active_branch"
         echo "Active branch set to: $active_branch"
         exit_loop=1
         break
      else
          echo "This selection does not exist: Select any number from 1-(${#branchArray[@]})"
      fi
   done # END of select
   done # END of while
} # END of function


#----------------------------------------------------------------
# checkWhichBranch 
# checks the WebRaap v4.x install if WR5 mode is activated
#
# Usage
# checkWhichBranch <Path to domain>
#
# Arguments
# <path to domain>: PATH to app domain
#
# Global arguments
# Required: Default Main branch name (global variable $default_branch)
# Required: Feature branch name (global variable $feature_branch_wr4)
# Required: $wrn_active_search_string
#
# Returns
# $active_branch: Active branch name in (global)

function checkWhichBranch() {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # Read the argument
   local domain_path=$1

   # Check if PATH to app domain is set
   if [ -r "$domain_path" ]; then
      log notice "Domain $domain_path exists and is readable"

      # Find WRN_ACTIVE=1 in the webraap 4.x install config/wr-config.php
      if [ -r "$domain_path/config/wr-config.php" ]; then
         log notice "Found $domain_path/config/wr-config.php";
          # Determine if WR5 feature branch is active in the WR4 install
         if grep -Fq "$wrn_active_search_string" "$domain_path/config/wr-config.php"
         then
             log notice "WR5 Feature branch ($feature_branch_wr4) is active in this WR4 install"
            # "return"
            active_branch=$feature_branch_wr4;
         else
            # Check for variation (1 instead of 'true')
            if grep -Fq "$wrn_active_search_string_variation" "$domain_path/config/wr-config.php"
            then
               log notice "WR5 Feature branch ($feature_branch_wr4) is active in this WR4 install"
               # "return"
               active_branch=$feature_branch_wr4;
            else
               log notice "Feature branch is not active. Using default branch ($default_branch)"
               active_branch=$default_branch
            fi # END of variation check
         fi # END of 1st check
      else
       log error "Cannot read wr-config in $domain_path/config";
      fi # END of wr-config.php check
   else
       log error "Application domain ($domain_path) not selected or not readable. Exiting..."
   fi # END of if $domain_path is empty

}
# END of function


#----------------------------------------------------------------
# selectSeeders()
# List available laravel seeders, asks user to select a seeder and import that seeder
#
# Usage
# selectSeeders <path to domin>
#
# Arguments
# <path to domain>: PATH to app domain
# Returns ?

function selectSeeders() {
   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # Read the argument
   local domain_path=$1

   # check if path exists and is readable
   if [ -r "$domain_path" ]; then
      cd "$domain_path/database/seeders"
      declare -a seedersArray
      for file in *.php
      do
         seedersArray=("${Seeder[@]}" "$file")
      done
   else
       log error "Application domain ($domain_path) not found or not readable"
   fi

}
# END of function

#----------------------------------------------------------------
# setAppType()
# Determines app type (webraap4/webraap5) by checking for the
# wr-config.php or .env file and also checks and sets the
# app_repo_path and the default branch
#
# Arguments: $domain_path
# Required: $reposPath (global)
# Required: $reposNameArray
#
# Returns: $app_type:   App type as $app_type (global)
#          $app_repo_path: (via setAppRepoPath function)
function setAppType() {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "
   log trace "-- Arguments: $@"

   # Read the argument
   local domain_path=$1

   # check if path exists and is readable
   if [ -r "$domain_path" ]; then
      log notice "Domain $domain_path exists and is readable"
      # Determine application type and matching repo
      if [[ -r "$domain_path/config/wr-config.php" ]]; then
         log notice "Found a WebRaap 4 install"
          app_type="webraap4";
          setAppRepoPath "$app_type" "$reposPath" "${reposNameArray[@]}";
          # Function returns matching repo path
          app_repo_path="$app_repository_path"
          # Check if WR4 is a "WR5 combi install". If so then apply feature branch
          checkWhichBranch "$domain_path" # 'returns' $active_branch
      elif [[ -r "$domain_path/.env" ]]; then
         log notice "Found a WebRaap 5 install"
         app_type="webraap5";
         log notice "Set app_type to $app_type"
         setAppRepoPath "$app_type" "$reposPath" "${reposNameArray[@]}";
         # Function 'returns' matching repo path
         app_repo_path="$app_repository_path"
         log notice "Matching repo path for app type: $app_type is $app_repo_path";
         # Setting default branch
         active_branch="$default_branch";
      fi
   else
       log error "Application domain ($domain_path) not selected or not readable. Exiting..."
   fi

}
# END of function

#----------------------------------------------------------------
## function appUpdate
# Updates the application (either wro or wr5+) from a repository
# Usage
# appUpdate <command> <path to domain> <npm command>
#
# Arguments
# <command>
# - update: update the software for the app domain 
# - migrate: Run artisan migrate on app domain
# - rebuild: Rebuild (npm run prod) the app
# - rebuildmigrate: Migrate & rebuild the app
# - seeder: Run custom Seeder on app domain
# - rebuilddbmigrate: Migrate and run php artisan db:migrate
# - vuepress: Rebuild the Vuepress doc install
# - install: Install new npm/compser modules 
# - backup: Create database exports with mysqldump

# <path to domain>: PATH to domain application folder
# <npm command>: NPM command

function appUpdate() {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # Read the arguments
   local update_mode=$1
   local domain_path=$2
   local npmcommand=$3

   # Check if an empty domain was supplied. The select/case combination in the
   # function appSelect() does not offer any way to check for incorrect of empty
   # input. If the user supplies incorrect/no input a global error variable is set.
   # Check for that and exit correctly

   # check if path exists and is readable
   if [ -r "$domain_path" ]; then
      log notice "Domain $domain_path exists and is readable"

      # -----------------------------------------------------
      # This will set required global variables. See function
      setAppType "$domain_path";

# ------------------------------------------------------------------
      # Mega case for each update mode
      case "$update_mode" in

# - Update command ------------------------------------------------
          update)

            # -------------------------------------------------------------------
            # Check if app is a local repo (git pull) or mirrored clone (git fetch)
            if [ -d "$domain_path/.git" ]; then
               log notice "The application ($domain_path) is a cloned git repo. Using git pull"
               cd "$domain_path";
               echo -e $green"--- Updating application ($domain_path)$colorclear - Branch: $active_branch"
               # Check which app_type is active
               if [ "$app_type" == "webraap5" ]; then
                  # Check if Branch selection was forced by user or config
                  if [ "$select_branch" == true ]; then
                     log notice "Selecting branch was forced by user or config"
                     selectBranch2 $app_repo_path $fb_prefix 
                  else
                     log notice "Branch selection was not forced. Using active branch as set by setAppType() ($active_branch)"
                  fi
               elif [ "$app_type" == "webraap4" ]; then
                  # Branch selection cannot be forced. checkWithBranch() has set the active branch type
                     log notice "Webraap4 install. Using active branch as set by checkWhichBranch() ($active_branch)"
               else
                  log error "Incorrect app_type ($app_type) was used"
               fi

               # Running git update commands --------------------
               git checkout $active_branch
               log notice "Running git pull --all to update"
               git pull --all
               cd "$current_path" # return to path

            # -------------------------------------------------------------------
            # App is a mirrored clone (git fetch)
            else
               log notice "The application ($domain_path) is a mirrored clone. Using Git checkout"
               echo -e $green"--- Updating application ($domain_path)$colorclear - Branch $active_branch"

                # Check which app_type is active
               if [ "$app_type" == "webraap5" ]; then
                  # Check if Branch selection was forced by user or config
                  if [ "$select_branch" == true ]; then
                     log notice "Selecting branch was forced by user or config"
                     selectBranch2 $app_repo_path $fb_prefix
                  else
                     log notice "Branch selection was not forced. Using active branch as set by setAppType() ($active_branch)"
                  fi
               elif [ "$app_type" == "webraap4" ]; then
                  # Branch selection cannot be forced. checkWithBranch() has set the active branch type
                     log notice "Webraap4 install. Using active branch as set by checkWhichBranch() ($active_branch)"
               else
                  log error "Incorrect app_type ($app_type) was used"
               fi

               # Running git update commands --------------------
               log notice "Running git checkout $active_branch to switch & update"
               git --work-tree="$domain_path" --git-dir="$app_repo_path" checkout -f $active_branch
               echo -e $green"--- Git Checkout was executed.$colorclear Rebuild the app when required!"
            fi # END of if local clone vs mirrored clone

          ;;
# END of case update) command --------------------------


# - migrate command ------------------------------------------------
          migrate)
            if [ "$app_type" == "webraap5" ]; then
                if [[ "$enable_backups" == "true" && ( "$db_backup_before_migrate" == "true" || "$db_backup_before_migrate_cmdline" == "true" ) ]]; then
                    # Run backup function
                    dbConnect "$db_user_global_enable" "$read_db_password_from_config" "$domain_path" "$app_type"
                    dbBackup "$backup_path" "$domain_path" "$app_type"
                else
                    echo -e $red"Warning:$colorclear database backups are disabled"
                fi
                cd "$domain_path"
                echo "--- Migrating database"
                php artisan migrate
                cd "$current_path"
                echo -e $green"--- The app domain ($domain_path) was migrated.$colorclear Check for errors if any!"
            elif [ "$app_type" == "webraap4" ]; then
                log warning "This domain ($domain_path) cannot be migrated ($app_type)";
            fi
          ;;

# - rebuild command ------------------------------------------------
          rebuild)
            # Rebuilding app
             if [ "$app_type" == "webraap5" ]; then
               log notice "Rebuilding WR5 install with command $npm_command"
               echo -e $green"--- Rebuilding WR5 install (command $npm_command)$colorclear"
               cd "$domain_path"
               composer dump-autoload
               $npmcommand
               cd "$current_path"
               echo -e $green"--- The app domain ($domain_path) was rebuild.$colorclear Check for errors if any!"
             elif [ "$app_type" == "webraap4" ]; then
               log notice "Rebuilding WR4 install with composer"
               echo -e $green"--- Rebuilding WR4 install with composer$colorclear"
               cd "$domain_path"
               composer update
               composer dump-autoload
               cd "$current_path"
               echo -e $green"--- The app domain ($domain_path) was rebuild.$colorclear Check for errors if any!"
             else
              log error "appRebuild(): Unknown app type"
             fi
          ;;

# - rebuild & migrate command ------------------------------------------------
          rebuildmigrate)
            if [ "$app_type" == "webraap5" ]; then
                log notice "Migrating database and rebuilding with command $npm_command"
                if [[ "$enable_backups" == "true" && ( "$db_backup_before_migrate" == "true" || "$db_backup_before_migrate_cmdline" == "true" ) ]]; then
                    # Run backup function
                    dbConnect "$db_user_global_enable" "$read_db_password_from_config" "$domain_path" "$app_type"
                    dbBackup "$backup_path" "$domain_path" "$app_type"
                else
                    echo -e $red"Warning:$colorclear database backups are disabled"
                fi
                echo -e $green"--- Migrating database and rebuilding app$colorclear"
                cd "$domain_path"
                php artisan migrate
                composer dump-autoload
                $npmcommand 
                echo -e $green"--- The app domain ($domain_path) was rebuild and migrated.$colorclear Check for errors if any!"
            elif [ "$app_type" == "webraap4" ]; then
                log warning "This $app_type app domain ($domain_path) does not support migration.";
                log info "Rebuilding $app_typex app without migration!";
                cd "$domain_path"
                composer update
                composer dump-autoload
                cd "$current_path"
                echo -e $green"--- The app domain ($domain_path) was rebuild.$colorclear Check for errors if any!"
            fi
          ;;

 # - run a custom seeder on app domain ------------------------------------------------
          seeder)  
            if [ "$app_type" == "webraap5" ]; then
                log notice "Importing Seeder in database"
                if [[ "$enable_backups" == "true" && ( "$db_backup_before_migrate" == "true" || "$db_backup_before_migrate_cmdline" == "true" ) ]]; then
                    # Run backup function
                    dbConnect "$db_user_global_enable" "$read_db_password_from_config" "$domain_path" "$app_type"
                    dbBackup "$backup_path" "$db_user_global_enable" "$domain_path" "$app_type"
                else
                    echo -e $red"Warning:$colorclear database backups are disabled"
                fi
                echo -e $green"--- Importing a laravel seeder$colorclear"
                cd "$domain_path"
                echo -e $green"- Listing most recent seeder files$colorclear"
                  selectSeeders "$domain_path"
                #echo -e $green"--- The seeder was imported in the database on app domain ($domain_path).$colorclear Check for errors if any!"
                cd "$current_path"
            elif [ "$app_type" == "webraap4" ]; then
                log warning "This WebRaap app ($domain_path) does not support Seeder imports ($app_type)";
            fi
          ;;

# - rebuild & DB:migrate command ------------------------------------------------
          rebuilddbmigrate)
            if [ "$app_type" == "webraap5" ]; then
                log notice "DB:Migrating database and rebuiding app"
                if [[ "$db_backup_before_migrate" == "true" || "$db_backup_before_migrate_cmdline" == "true" ]]; then
                    # Run backup function
                    dbConnect "$db_user_global_enable" "$read_db_password_from_config" "$domain_path" "$app_type"
                    dbBackup "$backup_path" "$db_user_global_enable" "$domain_path" "$app_type"
                fi
                echo -e $green"--- DB:Migrating database and rebuilding app$colorclear"
                cd "$domain_path"
                php artisan db:migrate
                composer dump-autoload
                $npmcommand
                cd "$current_path"
                echo -e $green"--- The dabase was migrated and the app ($domain_path) was rebuild!$colorclear Check for errors if any!"
            elif [ "$app_type" == "webraap4" ]; then
                log warning "This $app_type app domain ($domain_path) does not support db:migration.";
                log info "Rebuilding $app_type app (composer update) without db:migration!";
                cd "$domain_path"
                composer update
                composer dump-auto
                cd "$current_path"
                echo -e $green"--- The app domain ($domain_path) was rebuild.$colorclear Check for errors if any!"
            fi
          ;;

# - rebuild & DB:migrate command ------------------------------------------------
          vuepress)
            echo -e $green"--- Rebuilding Vuepress$colorclear"
            cd "$domain_path"
            npm run docs:build
            cd "$current_path"
            echo -e $green"--- Vuepress was rebuild on the app domain ($domain_path).$colorclear Check for errors if any!"
          ;;

# - Install new modules npm/composer ------------------------------------------------
          install)
            echo -e $green"--- Installing new modules$colorclear"
            cd "$domain_path"
            npm install
            composer install
            composer dump-autoload
            cd "$current_path"
            log info "Make sure to rebuild the app after installing new modules"
            echo -e $green"--- New composer/npm modules were installed on the app domain ($domain_path).$colorclear Check for errors if any!"
          ;;

# - Database Backups  ------------------------------------------------
          backup)
            echo -e $green"--- Starting database backup utility$colorclear"
            if [[ "$enable_backups" == "true" ]]; then
               dbConnect "$db_user_global_enable" "$read_db_password_from_config" "$domain_path" "$app_type"
               dbBackup "$backup_path" "$db_user_global_enable" "$domain_path" "$app_type"
               echo ""
            fi
          ;; 

      esac
      # END of mega case
# - END of mega case ------------------------------------------------

   else
       log error "Application domain ($domain_path) not selected or not readable. Exiting..."
   fi
   # END of if domain path exists
}
# END of function



#-----------------------------------------------------------------------
# appSelect
# Let user select app domain or command
#
# Usage
# appSelect <command> <domain array>
#
# NOTE: commands for the dbTools function require the 'dbtools_' prefix!
#
# Arguments
# <command>: See appUpdate() or dbTools() for list of commands
# <domain array>: domainPathArray [Array] with domain paths 
#
# See also https://linuxhint.com/bash_select_command/ for info on bash select command

function appSelect() {
   # Logging
   log debug "Started function ${FUNCNAME[0]} "
   # Set prompt (environment variable)
   # Settings colors in PS3 does not work like PS1/PS2 !! Bug/feature!
   PS3=$'\e[01;33mChoose app domain (a=all, q=exit menu ,l=list apps): \e[0m'
   # Set Column (environment variable)
   COLUMNS=1;

   # read array from arguments
   # Determine modus
   local app_mode=$1
   shift

   # read array with domain paths
   local domain_path_array=("$@");

   echo "$(colorYellow '--- Choose application domain') (modus:$app_mode)"

   select sel_option in "${domain_path_array[@]}"; do
      # Check the selected menu item number
      # Check first if user supplied special command instead of selecting
      if [ "$REPLY" == "a" ] || [ "$REPLY" == "l" ] || [ "$REPLY" == "q" ]; then
         case "$REPLY" in
            a) 
               read -p "Are you sure you want to $app_mode all the app domains? (y/n) " answer
               case $answer in
                 [yY] )
                   for appdomain in "${domain_path_array[@]}"; do
                      appUpdate "$app_mode" "$appdomain" "$npm_command"
                   done
                   break;
                 ;;
                 [nN] )
                     echo "exiting..."
                  listDomains ${domain_path_array[@]}
                 ;;
                 *) echo "Invalid answer"
                  listDomains ${domain_path_array[@]}
                 ;;
               esac
            ;;
            l) echo "$(colorYellow '--- Choose application domain')";
               listDomains ${domain_path_array[@]}
            ;;
            q) break;;
            *) echo "Unknown option. Choose a domain or command (a=all, q=exit menu, l=list)";
            ;;
         esac
      # The user is just selecting a domain
      elif [[ "$REPLY" =~ $is_integer ]] && [ 1 -le "$REPLY" ] && [ "$REPLY" -le $# ]; then

         # If db tools is enabled (see defaults) then run another function
         # WARNING: To make a distinction between "appUpdate" and "dbTools" commands any command for
         # the dbTools function require the 'dbtools_' prefix
         if [[ "$enable_dbtools" == "true" && "$app_mode" =~ "dbtools_" ]]; then
            log debug "-- db tooling is enabled. Running dbTools function with command:$app_mode"
            dbTools "$app_mode" "$sel_option"
         else 
            appUpdate "$app_mode" "$sel_option" "$npm_command"
            # After updating list the available domains again
         fi
         listDomains ${domain_path_array[@]}
      else
         echo "Non existing domain selection: Select any number from 1-$#"
      fi
   done # END of select
}
# END of function


#-----------------------------------------------------------------------
# dbToolSelect() 
#
# Select db tools
#
# Usage
# toolSelect <domain array>
#
# NOTE: dbTools commands require the 'dbtools_' prefix
#
# <Domain array>: domainPathArray [Array] with domain paths


function dbToolSelect() {
   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # read array with domain paths
   local domain_path_array=("$@");
   log debug "Arguments: ${domain_path_array[@]} "

   # Build menu

   echo "$(colorYellow '----------------------------------------------')"
   echo "$(colorYellow ' DB Tool menu')"
   echo ""
   echo "$(colorYellow ' ***************************************')"
   echo "$(colorYellow ' # !!!!!!WARNING WARNING WARNING!!!!!! #')"
   echo "$(colorYellow ' ***************************************')"
   echo ""
   echo "$(colorYellow ' Some db tools will only work when the database user has administrative permissions!')"
   echo "$(colorYellow ' These options will REMOVE/DELETE/DESTROY tables or complete databases!!!!!')"
   echo ""
   echo "$(colorBlue '--- DB tool options')"
   echo "$(colorGreen ' 1)') Delete ALL tables from database"

   echo "$(colorGreen ' q)') quit"
   echo -ne "$(colorBlue 'Choose an option:')"
   read a
   case $a in
      1) appSelect dbtools_deletetables ${domain_path_array[@]}; dbToolSelect; ;;
      q|Q) unset SUDO_PROMPT; mainmenu ;;
      *) echo "$(colorRed 'Wrong option. Try again (q to exit)')"; dbToolSelect ;;
   esac

} # END of toolSelect

#----------------------------------------------------------------
# function dbTools 
#
# Runs various db tooling options
#
# Usage
# dbTools <command> <path to domain> 
#
# Arguments
# - command (see case statement below)
# - db username
# - db password
# NOTE: dbTools commands require the 'dbtools_' prefix
# - dbtools_deletetables: delete all tables from database 
#
# <path to domain>: PATH to domain application folder
#
# Globals
# - $app_type (Set by function setAppType)

function dbTools() {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "

	# Header
	echo "*****************************************************"
	echo "* DB Tooling                                        *"
	echo "*                                                   *"
	if [ "$db_user_global_enable" == "true" ]; then
		echo "Global database user set to: $dbuser_value          *"
  fi
	echo "*****************************************************"


   # Read the arguments
   local dbtool_mode=$1
   local domain_path=$2
   log debug "-- Running dbTools command '$dbtool_mode'"

   # Check if an empty domain was supplied. The select/case combination in the
   # function appSelect() does not offer any way to check for incorrect of empty
   # input. If the user supplies incorrect/no input a global error variable is set.
   # Check for that and exit correctly

   # check if path exists and is readable
   if [ -r "$domain_path" ]; then
      log notice "-- Domain $domain_path exists and is readable"

   # -----------------------------------------------------
   # This will set required global variables like app_type. See function
   setAppType "$domain_path";

   # Display dry mode
   if [ "$dry_run" == "true" ]; then
       echo -e $orange"-- Dry run mode is enabled. Commands will not be executed"
   fi
   # ------------------------------------------------------------------
   # Mega case for each update mode
   case "$dbtool_mode" in

      # - Delete all tables command ------------------------------------------------
      dbtools_deletetables)
         echo -e $red"##### WARNING #####"
         echo -e $red" This will DELETE ALL TABLES in the requested db"$colorclear
         read -p "Are you VERY sure (Y/N)? : " answer
         case $answer in
            [yY] )
                  # Connect to database
                  dbConnect "$db_user_global_enable" "$read_db_password_from_config" "$domain_path" "$app_type"

                  # Determine app_type wr5/
                  if [[ "$app_type" == "webraap5" ]]; then
                     dropDbTables "$dbuser_value" "$dbname_value"
                     dropDbTables "$dbuser_wro_value" "$dbname_wro_value"
                  fi # END of app_type = wr5

                  # Check if app_type is wr4
                  if [[ "$app_type" == "webraap4" ]]; then
                     dropDbTables "$dbuser_wro_value" "$dbname_wro_value"
                  fi # END of app_type = wr4

             ;;
            [nN] )
               echo "Cancelling the deletion of all tables... phew!"
               dbToolSelect "${domainPathArray[@]}"
            ;;
            * )
               echo "Incorrect choice. Choose Y/N next time... "
            ;;
         esac
      ;;
   esac # END of mega case
   # - END of mega case ------------------------------------------------

   else
       log error "Application domain ($domain_path) not selected or not readable. Exiting..."
   fi
   # END of if domain path exists

} # END of function

#-----------------------------------------------------------------------
# dropDbTables() 
# Removes ALL tables from the given database
# This function will force the user to enter the database password to prevent mistakes
#
# Usage dropDbTables <db user> <db name> 
#
# Arguments
# - database name
#
# Global arguments
# - $enable_backups
# - $backup_path
# - $dry_run
# - $current_path
#
function dropDbTables() {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # Read arguments
   local dbuser_value=$1
   local dbname_value=$2
   # defaults
   local temp_drop_tables_path=""

   # Lets check if the $backup_path is available
   if [ "$enable_backups" == "true" ]; then
      # If backups are enabled, the backup_path is available!
      temp_drop_tables_path="$backup_path"
   else
      # Backup path not available. Lets test the current folder
      if [ -w "$current_path" ]; then
         # Current path is writable. Using that
         temp_drop_tables_path="$current_path"
      fi
   fi

   if [ -z "$temp_drop_tables_path" ]; then
       # backup path and current path are both not available.
      log warning "dropDbTables cannot execute because missing a writable path "
      log warning "Backup path and current path are not available or writable. Cannot create temporary sql files"
   else
      if [ "$dry_run" == "false" ]; then
         # Creating temporary sql file for dropping tables 
         echo "SET FOREIGN_KEY_CHECKS = 0;" > $temp_drop_tables_path/droptables.sql; \
         echo "-- Creating temporary sql file with drop tables queries"
         mysqldump -u "$dbuser_value" -p --add-drop-table --no-data "$dbname_value" | grep ^DROP >> $temp_drop_tables_path/droptables.sql; \
         echo "SET FOREIGN_KEY_CHECKS = 1;" >> $temp_drop_tables_path/droptables.sql; \
         echo "-- Preparing to drop all tables for table: $dbname_value... "
         mysql --user="$dbuser_value" -p --verbose $dbname_value < $temp_drop_tables_path/droptables.sql;
         echo "-- All tables have been dropped.. Its too late now. I hope there is an backup."
         # Removing temporary sql
         log debug "-- Removing temporary sql file ($temp_drop_tables_path/droptables.sql"
         rm "$temp_drop_tables_path/droptables.sql"
         if [ -e "$temp_drop_tables_path/droptables.sql" ]; then
            log warning "The temporary sql file could not be removed. Remote it manually with command rm -f $temp_drop_tables_path/droptables.sql"
         fi
     else
         echo "-- Dry run mode active"
         echo "-- Would have created a temporary sql file, run the mysqldump command, dropped tables and removed temp sql file"
      fi
   fi

} # END of function


#-----------------------------------------------------------------------
# dbConnect()
# Connect to the specified database
#
# Usage dbConnect <db_user_global_enable> <read_db_password_from_config> <domain_path> <app_type>
#
# Arguments
# - db_user_global_enable
# - read_db_password_from_config
# - domain_path
# - app_type
#
# Global Arguments
# - $dry_run
#
# Returns
# - dbname_value 
# - dbname_wro_value
# - dbuser_value
# - dbuser_wro_value
# - dbpassword_value
# - dbpassword_wro_value

function dbConnect() {

   # Logging
	log debug "Started function ${FUNCNAME[0]} "
	log debug "-- Function arguments: $*"

	# Header
	echo -e $colorclear""
	colorYellow "Setting up the mysql database connection"
	echo ""	

# Defaults

# mysqldump password prompt
manual_password_mode="false"

# Reading arguments
local db_user_global_enable=$1
local read_db_password_from_config=$2
local domain_path=$3
local application_type=$4


# Check if db password should be read from config
if [ "$read_db_password_from_config" == "true" ]; then
    # db password should be read from config
    log notice "-- Reading db password from config file"
fi

# Check and set the path(s) to the wrn/wro config files
# Set config file path
if [ "$application_type" == "webraap5" ]; then
    app_config_file="$domain_path/.env"
		if [ ! -r "$app_config_file" ]; then
			log error "The wr5+ config file ($app_config_file) does not exists or is not readable"
		fi
else
    if [ "$application_type" == "webraap4" ]; then
      app_config_file="$domain_path/config/wr-config.php"
			if [ ! -r "$app_config_file" ]; then
				log error "The wr4 config file ($app_config_file) does not exists or is not readable"
			fi
    else
      log error "-- The argument app_type with value: $application_type is not valid"
    fi
fi
log debug "-- app_config_file has been set to: $app_config_file"

	# Read the application config file for database details
	log debug "-- Reading database credentials from $app_config_file. Please wait..."
	echo "-- wrupdate is enabled to read the mysql password from wrn/wro config files"

# Loop through the array and import the revelant variables and values
# See the wrupdate.conf files for the definition arrays. And YES the wr5DbDefArray also has
# definitions for the wr4 database!

if [[ "$app_type" == "webraap5" ]]; then
   search_key_dbname_ref="${wr5DbDefArray['dbname_ref']}"
   search_key_dbuser_ref="${wr5DbDefArray['dbuser_ref']}"
   if [[ "$read_db_password_from_config" == "true" ]]; then
      search_key_dbpassword_ref="${wr5DbDefArray['dbpassword_ref']}"
   fi
   search_key_dbname_wro_ref="${wr5DbDefArray['dbname_wro_ref']}"
   search_key_dbuser_wro_ref="${wr5DbDefArray['dbuser_wro_ref']}"
   if [[ "$read_db_password_from_config" == "true" ]]; then
      search_key_dbpassword_wro_ref="${wr5DbDefArray['dbpassword_wro_ref']}"
   fi
fi
if [[ "$app_type" == "webraap4" ]]; then
   search_key_dbname_wro_ref="${wr4DbDefArray['dbname_wro_ref']}"
   search_key_dbuser_wro_ref="${wr4DbDefArray['dbuser_wro_ref']}"
   if [[ "$read_db_password_from_config" == "true" ]]; then
      search_key_dbpassword_wro_ref="${wr4DbDefArray['dbpassword_wro_ref']}"
   fi
   log debug "-- Found search_key_dbname_wro_ref: $search_key_dbname_wro_ref"
   log debug "-- Found search_key_dbuser_wro_ref: $search_key_dbuser_wro_ref"
   log debug "-- Found search_key_dbpassword_wro_ref: $search_key_dbpassword_wro_ref"
fi

# instead of looping through the definition array, and having to
# read the config file multiple times, we just use multiple ifs
# the fancy 'sed' command: https://stackoverflow.com/a/18274451
# sed removes leading and trailing sinlge and double quotes
#
# NOTE: The variable definition in wr-config.php MUST be done with ' ' single quotes otherwise the 'sed' command wont work

if [ "$application_type" == "webraap5" ]; then
    while IFS= read -r line; do
        log trace "Reading line from .env: ${line}" 
        if [[ "$line" == "$search_key_dbname_ref="* ]]; then
            log debug "${line}"
            dbname_value="$(echo ${line#*=} | sed "s/['\"]//g")"""
        fi
        if [[ "$line" == "$search_key_dbuser_ref="* ]]; then
            log debug "${line}"
            dbuser_value="$(echo ${line#*=} | sed "s/['\"]//g")"""
        fi
        if [[ "$read_db_password_from_config" == "true" && "$line" == "$search_key_dbpassword_ref="* ]]; then
            log debug "${line}"
            dbpassword_value="$(echo ${line#*=} | sed "s/['\"]//g")"""
        fi
        if [[ "$line" == "$search_key_dbname_wro_ref="* ]]; then
            log debug "${line}"
            dbname_wro_value="$(echo ${line#*=} | sed "s/['\"]//g")"""
        fi
        if [[ "$line" == "$search_key_dbuser_wro_ref="* ]]; then
            log debug "${line}"
            dbuser_wro_value="$(echo ${line#*=} | sed "s/['\"]//g")"""
        fi
        if [[ "$read_db_password_from_config" == "true" && "$line" == "$search_key_dbpassword_wro_ref="* ]]; then
            log debug "${line}"
            dbpassword_wro_value="$(echo ${line#*=} | sed "s/['\"]//g")"""
        fi
    done < "$app_config_file"
fi

if [ "$application_type" == "webraap4" ]; then
        log debug "-- App type is webraap4. Reading $app_config_file for database credentials"
    while IFS= read -r line; do
        log trace "Reading line from wr-config.php: ${line}" 
        if [[ $(echo "$line" | sed -n "s/\(\$[a-zA-Z_][a-zA-Z0-9_]*\).*/\1/p") == "$search_key_dbname_wro_ref" ]]; then
          dbname_wro_value=$(echo "$line" | grep -oP "\s*=\s*'[^']*'" | awk -F"'" '{print $2}')
					log debug "-- dbname_wro_value is: $dbname_wro_value"
        fi
        if [[ $(echo "$line" | sed -n "s/\(\$[a-zA-Z_][a-zA-Z0-9_]*\).*/\1/p") == "$search_key_dbuser_wro_ref" ]]; then
          dbuser_wro_value=$(echo "$line" | grep -oP "\s*=\s*'[^']*'" | awk -F"'" '{print $2}')
					log debug "-- dbuser_wro_value is: $dbuser_wro_value"
        fi
        if [[ $(echo "$line" | sed -n "s/\(\$[a-zA-Z_][a-zA-Z0-9_]*\).*/\1/p") == "$search_key_dbpassword_wro_ref" ]]; then
          dbpassword_wro_value=$(echo "$line" | grep -oP "\s*=\s*'[^']*'" | awk -F"'" '{print $2}')
					log debug "-- dbpassword_wro_value is: $dbpassword_wro_value"
        fi

    done < "$app_config_file"
fi

# Display Database credentials found
if [[ "$read_db_password_from_config" == "true" ]]; then
    echo "-- Database credentials are read from the config file"
    if [[ -n "$dbname_value" ]]; then
        log notice "1. Database name (wrn): $dbname_value"
    fi
    if [[ -n "$dbname_wro_value" ]]; then
        log notice "1. Database name (wro): $dbname_wro_value"
    fi
    if [[ -n "$dbuser_wro_value" ]]; then
        log notice "2. Mysql username (wro): $dbuser_wro_value"
    else
        log notice "2. Mysql username (wrn): $dbuser_value"
    fi
    if [[ -n "$dbpassword_value" ]]; then
        log notice "1. Database (wrn) dbpassword_: $dbpassword_value"
    fi
    if [[ -n "$dbpassword_wro_value" ]]; then
        log notice "1. Database (wro) password: $dbpassword_wro_value"
    fi
else
   echo "-- No database credentials are found. Enter the database credentials manually"
   read -p "1. Mysql database name: " db_name_input
   if [[ ! $db_user_global == 'DB_USER_GLOBAL_DEFAULT' ]]; then
       log notice "2. Mysql username: $db_user_global"
   else
      read -p "2. Mysql username: " db_username_input
   fi
   echo "You will be promted for the database password when required."
   manual_password_mode="true"
fi

# Check if global database username should be used. If not ask user for username
if [[ "$db_user_global_enable" == "false" ]]; then
   log notice "-- Global database user has not been set. Asking user for db username"
   log info "A global database username was not set in the config file. Add it to skip the next step"
   read -p "-- Enter the database username: " dbuser_value 
   log debug "-- Database username set by user to $dbuser_value"
	# Set the database user for wro environment
	dbuser_wro_value="$dbuser_value"
else
   dbuser_value="$db_user_global"
   dbuser_wro_value="$db_user_global"
   log debug "-- Database username (dbuser_value) has been set to $db_user_global"
fi


# Overwrite db credentials with user input if available
if [[ -n "$db_name_input" ]]; then
    log debug "-- User supplied database name: $db_name_input"
    dbname_value="$db_name_input"
    dbname_wro_value="$db_name_input"
fi
if [[ -n "$db_username_input" ]]; then
    log debug "-- User supplied username: $db_username_input"
    dbuser_value="$db_username_input"
    dbuser_wro_value="$db_username_input"
fi

# check for special characters and spaces in the db password.
# mysql/mysqldump does not work with special characters or spaces
# on the commandline even with proper quoting... go figure...

if [[  "$dbpassword_value" =~ ' ' || "$dbpassword_value" =~ ['!@#$%^&*()_+'] ]]; then
    log warning "-- The password contains spaces, and/or special characters."
    log warning "-- Switching to manual password prompt for mysqldump!"
    manual_password_mode="true"
fi
if [[  "$dbpassword_wro_value" =~ ' ' || "$dbpassword_wro_value" =~ ['!@#$%^&*()_+'] ]]; then
    log warning "-- The password contains spaces, and/or special characters."
    log warning "-- Switching to manual password prompt for mysqldump!"
    manual_password_mode="true"
fi

# Debug logging
log debug "-- Database credentials wr5"
log debug "-- dbname_value is: $dbname_value"
log debug "-- dbuser_value is: $dbuser_value"
log debug "-- dbpassword_value is: $dbpassword_value"
log debug "-- Database credentials wro"
log debug "-- dbname_wro_value is: $dbname_wro_value"
log debug "-- dbuser_wro_value is: $dbuser_wro_value"
log debug "-- dbpassword_wro_value is: $dbpassword_wro_value"

} # END of function dbConnect

#
#-----------------------------------------------------------------------
# checkGrantsMysql()
# Checks the required privileges (grants) for the given user
#
# Required: dbConnect() has to be executed before running the grant check
# Usage: checkGrantsMysql 
#
# Arguments

function checkGrantsMysql() {
	# Logging
	log debug "Started function ${FUNCNAME[0]} "
	
	echo "Checking required mysql privileges for user: $dbuser_value"
	if [ "$manual_password_mode" == "true" ]; then
		echo "-- Manual password mode is enabled. Enter your mysql password"
	   log debug "-- Running command: mysql --user=\"$dbuser_value\" -p\"$dbpassword_value\" -e \"SHOW GRANTS FOR '\"$dbuser_value\"'@'localhost';\" |grep -E \"PROCESS|LOCK TABLES\"" 
	   grants=$(mysql --user="$dbuser_value" -p -e "SHOW GRANTS FOR '"$dbuser_value"'@'localhost';" | grep -E "PROCESS|LOCK TABLES")
	fi
	log debug "-- Running command: mysql --user=\"$dbuser_value\" -p\"$dbpassword_value\" -e \"SHOW GRANTS FOR '\"$dbuser_value\"'@'localhost';\" |grep -E \"PROCESS|LOCK TABLES\"" 
	grants=$(mysql --user="$dbuser_value" -p"$dbpassword_value" -e "SHOW GRANTS FOR '"$dbuser_value"'@'localhost';" | grep -E "PROCESS|LOCK TABLES")

	if [ -n "$grants" ]; then
    		echo "-- The mysql user $dbuser_value has the required mysql privileges to continue."
				log trace "-- user $dbuser_value has privileges: $grants"
	else
		log error "Mysql user does not have the required privileges to create database exports. Exit"
	fi

} # END of function


#-----------------------------------------------------------------------
# mysqlDump()
# Create database dump(s) for webraap5 and webraap4 detabase
# This function will check the app_type, dry_run mode and manual password mode
#
# Usage: mysqlDump <app type>
#
# Arguments
# - app type
#
# Global variables
# - dbuser_value | dbuser_wro_value
# - dbpassword_value | dbpassword_wro_value
# - dbname_value | dbname_wro_value
# - backup_path
# - backup_filename
# - manual_password_mode
# - dry_run

function mysqlDump() {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "
   log debug "-- Function arguments: $*"

   local app_type="$1"

   if [ "$dry_run" == "false" ]; then
      if [ "$app_type" == "webraap5" ]; then
         log debug "App type set to: $app_type"
         if [ "$manual_password_mode" == "false" ]; then
            echo "-- Creating database dump from wr5 database"
            mysqldump --verbose --user="$dbuser_value" --password="$dbpassword_value" -r "$backup_path/$dbname_value-$backup_filename" "$dbname_value"
            echo "-- Creating database dump from wr4 database"
            mysqldump --verbose --user=$dbuser_wro_value --password=$dbpassword_wro_value -r "$backup_path/$dbname_wro_value-$backup_filename" $dbname_wro_value
        else
            echo "-- Creating database dump from wr5 database. Enter mysql password for user $dbuser_value"
            mysqldump --verbose --user=$dbuser_value -p -r "$backup_path/$dbname_value-$backup_filename" $dbname_value
            echo "-- Creating database dump from wr4 database. Enter mysql password for user $dbuser_value"
            mysqldump --verbose --user=$dbuser_wro_value -p -r "$backup_path/$dbname_wro_value-$backup_filename" $dbname_wro_value
         fi
      else
         if [ "$manual_password_mode" == "false" ]; then
            echo "-- Creating database dump from wr4 database"
            mysqldump --verbose --user=$dbuser_wro_value --password=$dbpassword_wro_value -r "$backup_path/$dbname_wro_value-$backup_filename" $dbname_wro_value
         else
            echo "-- Creating database dump from wr4 database. Enter mysql password for user $dbuser_value"
            mysqldump --verbose --user=$dbuser_wro_value -p -r "$backup_path/$dbname_wro_value-$backup_filename" $dbname_wro_value
         fi
      fi

   else
     echo "Dry run mode is enabled."
     echo "Not executing: mysqldump"
   fi

   echo -e "$yellow-- Database:$colorclear $dbname_wro_value ($db_user_type)"

} # END of function

#-----------------------------------------------------------------------
# dbBackup()
# Create a database backup with mysqldump

# Requirements
# >>>> dbConnect MUST BE RUN BEFORE calling dbBackup <<<<
# dbConnect will set the required database credentials for both wr4/wr5 app types
# See return values in dbConnect()

# - The unix user must have sudo permission
# - <root> should be authorised to use start mysql using Unix sockets 
#          If mysql requires a password for <root> this will not work
# - backup_path must be configured in wrupdate.conf
# - Global database variable definitions (see wrupdate.conf) 
# - function dbConnect
#
# Usage: dbBackup <db username> <backup path> <domain path> <app type>
#
# Arguments
# - backup_path (global - is checked already)
# - domain_path
# - app_type

# Required Globals
# - wr5DbDefArray (global) - Array with database variable definitions
# - manual_password_mode - set by function dbConnect

# When db_user has been set in wrupdate.conf it will be used. If not the user
# will be requested to provide the username

function dbBackup() {

	
	# Logging
	log debug "Started function ${FUNCNAME[0]} "
	log debug "-- Function arguments: $*"

	# Header
	echo ""
	echo -e $yellow"*****************************************************"
	echo           "* Database backup utility                           *"
	echo           "*                                                   *"
	if [ "$db_user_global_enable" == "true" ]; then
		echo         "* Global database user set to: $dbuser_value            *"
  fi
	echo           "*****************************************************"
	echo -e ""$colorclear

# Read arguments
local backup_path=$1
local domain_path=$2
local application_type=$3

# Check required privileges
checkGrantsMysql

# Create filename for database backup
# format: <database name>_date_time.sql
local datetime_prefix=$(date +"%Y-%m-%d_%I_%M_%p")
local backup_filename="$datetime_prefix.sql"
echo ""
if [[ -n "$dbname_wro_value" ]]; then
   echo "-- Creating backup $dbname_wro_value-$backup_filename to $backup_path"
else
   echo "-- Creating backup $dbname_value-$backup_filename to $backup_path"
fi

# Creating database exports
mysqlDump "$app_type"

# Compressing backup file
# Check if compression was enabled
if [ "$compress_backup" ]; then
   log debug "Compression is enabled."
   # check application type
   if [[ "$app_type" == "webraap5" ]]; then

      # Check if the backup file is available
      if [[ -s "$backup_path/$dbname_value-$backup_filename" && -s "$backup_path/$dbname_wro_value-$backup_filename" ]]; then
         log debug "Found backup file: $backup_path/$dbname_value-$backup_filename"
         log debug "Found backup file: $backup_path/$dbname_wro_value-$backup_filename"
         # Check if gzip command is available
         # See https://stackoverflow.com/a/677212 for 'hash' explanation
         if hash gzip 2>/dev/null; then
            echo "Compression is enabled. Compressing database backup"
            echo "Compressing $dbname_value backup. Please wait..."
            if [ "$dry_run" == "false" ]; then
               gzip "$backup_path/$dbname_value-$backup_filename"
            else
               echo "Dry run mode enabled"
               echo "Not executing gzip"
            fi
            echo "Compressing $dbname_wro_value backup. Please wait..."
            if [ "$dry_run" == "false" ]; then
               gzip "$backup_path/$dbname_wro_value-$backup_filename"
            else
               echo "Dry run mode enabled"
               echo "Not executing gzip"
            fi
            echo "Compressing done..."
            transferBackup "$backup_path/$dbname_value-$backup_filename.gz"
            transferBackup "$backup_path/$dbname_wro_value-$backup_filename.gz"
         else
            log warning "Compression is unavailable. gzip is not found! Backup will not be compressed!"
         fi
      else
         if [ "$dry_run" == "false" ]; then
            echo -e $yellow"The backup file could not be found. Compression failed"$colorclear
         else
             echo "Dry run mode is enabled. Not compressing db dump file(s)"
         fi
         log debug "Removing empty backup files"
         if [ "$dry_run" == "false" ]; then
            rm "$backup_path/$dbname_value-$backup_filename"
            rm "$backup_path/$dbname_wro_value-$backup_filename"
         else
            echo "Dry run mode enabled"
            echo "Not removing db dump files"
         fi
      fi
   fi # End of app_type wr5 check

   # Check app_type is webraap4
   if [[ "$app_type" == "webraap4" ]]; then
      if [[ -s "$backup_path/$dbname_wro_value-$backup_filename" ]]; then
         log debug "Found backup file: $backup_path/$dbname_wro_value-$backup_filename"
         # Check if gzip command is available
         # See https://stackoverflow.com/a/677212 for 'hash' explanation
         if hash gzip 2>/dev/null; then
            echo "Compression is enabled. Compressing database backup."
            echo "Compressing $dbname_wro_value backup. Please wait..."
            if [ "$dry_run" == "false" ]; then
               gzip "$backup_path/$dbname_wro_value-$backup_filename"
               echo "Compressing done..."
               echo "hoi"
               transferBackup "$backup_path/$dbname_wro_value-$backup_filename.gz"
            else
               echo "Dry run mode enabled"
               echo "Not executing gzip"
            fi
         else
            log warning "Compression is unavailable. gzip is not found! Backup will not be compressed!"
         fi
      else
         echo -e $yellow"The backup file could not be found. Compression failed"$colorclear
         log debug "Removing empty backup files"
         if [ "$dry_run" == "false" ]; then
            rm "$backup_path/$dbname_wro_value-$backup_filename"
         else
            echo "Dry run mode enabled"
            echo "Not removing db dump files"
         fi
      fi
   fi

else
    log debug "Compression is disabled"
fi

# Footer
echo ""
echo -e $yellow"Choose another app to backup or q to exit"$colorclear

}
# END of function dbBackup()

#-----------------------------------------------------------------------
# transferBackup() 
# Transfer database backup to the destination node
#
# Usage
# transferBackup <backup file including PATH>
#
# Arguments
# <backup file incl PATH>
function transferBackup() {

   # Logging
   log debug "Started function ${FUNCNAME[0]} "

   # Read Arguments
   local backup_file_path=$1
   log trace "-- backup file and path: $backup_file_path"

   # Check if backup file exists
   if [[ -a "$backup_file_path" ]]; then
      log debug "-- Database backup file and path: $backup_file_path exists"
   else
      log fatal "-- Database backup file not found: $backup_file_path"
   fi

   echo "$(colorYellow '* Started transfer backup to failover')"
   echo -e $yellow"- The transfer of the backup file depends on ssh key so it might not work "$colorclear
   read -p "Are you sure to transfer the file to the failover node(Y/N)? : " answer
   case $answer in
      [yY] )
          log trace "-- backup file and path: $backup_file_path"
          log trace "dest: $backup_dest_hostname"
          log trace "account: $backup_dest_account"
          log trace "port: $backup_dest_port"
          log debug "scp -P $backup_dest_port $backup_file_path $backup_dest_account@$backup_dest_hostname:/home/$backup_dest_account"
          scp -P "$backup_dest_port" "$backup_file_path" "$backup_dest_account@$backup_dest_hostname:/home/$backup_dest_account"
         ;;
     [nN] )
         echo "Not transferring the backup file.."
         ;;
     * )
         echo "Incorrect choice. Choose Y/N next time... "
         ;;
   esac

} #END of function


#-----------------------------------------------------------------------
# selfUpdate() 
# Update this script
#
# Usage
# selfUpdate <path to git repos> <wrupdate script name> <wrupdate script path> <wrupdate repo folder name>
#
# Arguments
# <path to git repos>: $reposPath
# <wrupdate script name>: $script_name
# <wrupdate script path>: $script_path
# <wrupdate repo folder name>: $repo_wrupdate_folder_name
# 

function selfUpdate() {

# Logging
log debug "Started function ${FUNCNAME[0]} "

# Read Arguments
local repos_path=$1
local wrupdate_script_name=$2
local wrupdate_script_path=$3
local wrupdate_repo_folder_name=$4

echo "$(colorYellow '* Started selfupdating '$wrupdate_script_name)"

# Check if reposPath (in local repos_path exists)
if [[ -r "$repos_path" ]]; then
   echo "Repo path $repos_path exists"
else
   log fatal "Repository path is not readable or does not exist..."
fi
# Check if wrupdate repo folder exists
if [[ -r "$repos_path/$wrupdate_repo_folder_name" ]]; then
   log debug "wrupdate repo folder $repos_path/$wrupdate_repo_folder_name exist"
   # Check if supplied path is a mirrored clone
   # a mirrored clone does not have a .git folder and always has a "HEAD" folder
   if [[ -d "$repos_path/$wrupdate_repo_folder_name/.git" ]]; then
       echo "This is a cloned repository. Using git pull to update..."
       cd $repos_path/$wrupdate_repo_folder_name
       git pull
   else
       echo "Found a mirrored clone for $wrupdate_script_name. Using git fetch"
       cd $repos_path/$wrupdate_repo_folder_name
       log debug "Running git fetch -p origin on $repos_path/$wrupdate_repo_folder_name"
       echo "Running git fetch to update the repository"
       git fetch -p origin
       echo "Running git checkout to update $wrupdate_script_name"
       log debug "Running checkout to update $wrupdate_script_path from repo $repos_path/$wrupdate_repo_folder_name"
       # We need -f to force git to overwrite the running script!
       git --work-tree="$wrupdate_script_path" --git-dir="$repos_path/$wrupdate_repo_folder_name" checkout -l -f --progress
       echo "Git checkout was executed..."
   fi
else
    log fatal "wrupdate repository folder ($repos_path/$wrupdate_repo_folder_name) is not readable or does not exist..."
fi


# Back to current path (global)
cd "$current_path"

echo "$(colorYellow '* Selfupdating finished. Check for errors...')"

}
# End of function

#-----------------------------------------------------------------------
# Function header()
# Displays initial settings for wrupdate
#
# Usage
# header()
#
# Arguments: none

function header() {

# Logging
log debug "Started function ${FUNCNAME[0]} "

echo "$(colorYellow '----------------------------------------------')"
echo "$(colorYellow ' WebRaap Update Script')"
echo "$(colorYellow ' Version: ')$version";
echo "$(colorYellow ' User EPD API active: ')$userepd_api (command $npm_command)";
if [[ "$select_branch" == "true" ]]; then
   echo "$(colorYellow ' Branch selection is ')enabled";
fi
echo "$(colorYellow ' Default branch: ')$default_branch";
if [[ "$enable_backups" == "true" ]]; then
   echo "$(colorYellow ' Database backups enabled: ')$enable_backups";
   if [[ "$db_backup_before_migrate" == "true" || "$db_backup_before_migrate_cmdline" == "true" ]]; then
      echo "$(colorYellow ' - Auto backup database before migrate: ')enabled";
   fi
   echo "$(colorYellow ' - Read db password from config: ')$read_db_password_from_config";
fi
if [[ "$enable_dbtools" == "true" ]]; then
   echo "$(colorYellow ' DB tools enabled: ')$enable_dbtools";
fi
echo "$(colorYellow ' Forcing db:migrate option: ')$force_dbmigrate";
echo "$(colorYellow ' Git modus: ')$gitmodus";
if [ "$gitmodus" == "pull" ]; then
   echo " Some menu options are not available in the 'pull' git modus";
   echo " 'pull' modus will update each repo with 'git pull'";
else
   if [ "$gitmodus" == "fetch" ]; then
       echo " 'fetch' modus will update git repo's with 'git fetch -o origin'"
   fi
fi
echo "$(colorYellow ' Dry run mode enabled: ')$dry_run";
echo "$(colorYellow ' Log level set to: ')$log_level";
echo "$(colorYellow ' Logging to: ')$log_route";
if [[ "$log_file_name_path" == "true" ]]; then
   echo "$(colorYellow ' Log file: ')$log_file_name_path"
fi
}
# END of function

#-----------------------------------------------------------------------
# Function mainmenu()
# Displays the main menu
#
# Usage
# mainmenu()
#
# Arguments: none
# Requires the global array {domaintPathArray} to be set

function mainmenu(){
# Logging
log debug "Started function ${FUNCNAME[0]} "

echo "$(colorYellow '----------------------------------------------')"
echo "$(colorYellow ' WebRaap Update Main Menu')"
echo ""
echo "$(colorBlue '--- List of options')"
if [ "$gitmodus" == "fetch" ]; then
   echo "$(colorGreen ' 1)') Update all git repositories"
fi
echo "$(colorGreen ' 2)') Update app software"
echo "$(colorGreen ' 3)') Migrate app database"
echo "$(colorGreen ' 4)') Rebuild apps (no migrate)"
echo "$(colorGreen ' 5)') Rebuild apps with migrate"
echo "$(colorGreen ' 6)') Run custom seeders"
echo "$(colorGreen ' 7)') Rebuild Vuepress"
echo "$(colorGreen ' 8)') Install new modules (npm/composer)"
if [[ "$enable_backups" == "true" ]]; then
   echo "$(colorGreen ' 9)') Backup databases"
fi
if [[ "$enable_dbtools" == "true" ]]; then
   echo "$(colorGreen ' 10)') Databases tools"
fi
if [ "$force_dbmigrate" == true ]; then
   echo "$(colorGreen ' 99)') Rebuild apps and DB:MIGRATE!!"
fi
echo "$(colorGreen ' q)') quit"
echo -ne "$(colorBlue 'Choose an option:')"
read a
case $a in
   1) if [ "$gitmodus" == "pull" ]; then
            echo "$(colorRed ' Update git repos not available in pull modus')"
         mainmenu
      else
         repoUpdate "${reposNameArray[@]}";
         mainmenu;
      fi
      ;;

   2) appSelect update "${domainPathArray[@]}"; mainmenu ;;
   3) appSelect migrate  "${domainPathArray[@]}"; mainmenu ;;
   4) appSelect rebuild  "${domainPathArray[@]}"; mainmenu ;;
   5) appSelect rebuildmigrate  "${domainPathArray[@]}"; mainmenu ;;
   6) appSelect seeder  "${domainPathArray[@]}"; mainmenu ;;
   7) appSelect vuepress  "${domainPathArray[@]}"; mainmenu ;;
   8) appSelect install  "${domainPathArray[@]}"; mainmenu ;;
   9) appSelect backup  "${domainPathArray[@]}"; mainmenu ;;
   10) dbToolSelect "${domainPathArray[@]}"; mainmenu ;;
   99) appSelect rebuilddbmigrate "${domainPathArray[@]}"; mainmenu ;;
   q|Q) unset SUDO_PROMPT; exit 0 ;;
   *) echo "$(colorRed 'Wrong option. Try again (q to exit)')"; mainmenu ;;
esac
}
# END of function

#************************************************************************
# MAIN APPLICATION START
#
#************************************************************************

#-----------------------------------------------
# User check
# This script can only be run as the user with
# webroot file/group permissions

if [ "$(whoami)" = "root" ]; then
    log fatal "Do not execute directly as 'root'";
fi


#-----------------------------------------------
# Find git repositories at $reposPath PATH and add them to an array
log debug "Reading git repositories and initialising'"
initRepos $reposPath
log notice "Git repositories are initalized"

#-----------------------------------------------
# Check if self-update was requested. If not start mainmenu
if [ "$update_self" == true ]; then
   # Self update was requested
   echo "$(colorYellow '----------------------------------------------')"
   echo "$(colorYellow 'Selfupdate was requested')"
   echo "$(colorYellow '----------------------------------------------')"
   echo -e $yellow"-> The selfupdate will overwrite any changes to existing scripts in $script_path"$colorclear
   read -p "Are you sure (Y/N)? : " answer
   case $answer in
      [yY] )
         selfUpdate $reposPath $script_name $script_path $repo_wrupdate_folder_name
         ;;
     [nN] )
         echo "Exiting the selfupdate..."
         exit 1
         ;;
     * )
         echo "Incorrect choice. Choose Y/N next time... "
         ;;
   esac
else
   # Start ---------------------------------------
   # Start the main program
   log debug "Display app Header"
   header
   log debug "Starting main menu"
   mainmenu
fi

