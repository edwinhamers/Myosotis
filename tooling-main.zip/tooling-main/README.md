# Myosotis Tooling Library

# Table of contents
- [WR Update script](#wrupdatesh)
- [Xtra Backup (percona)](#xtrabackup)

# wrupdate.sh

This is a bash script that automates the updating and rebuilding of WebRaap applications.
See changelog for latest changes (https://github.com/myosotisgit/tooling/blob/main/CHANGELOG.md#changelog-wrupdatesh)

## installation
- Download or clone the git repository
- Create config file by copying `wrupdate.conf-sample` to `wrupdate.conf`
- Add your custom config values

## Using wrupdate
- use `wrupdate.sh` or `./wrupdate.sh` to start
- use `wrupdate.sh -h` to show the available options to run


# Installation Tooling Library

- Download or clone the repository
```git clone git@github.com:myosotisgit/tooling.git tooling.git```

- Update repository 
```git --work-tree=/home/myotest/bin/tooling --git-dir=/home/myotest/repos/tooling.git checkout -f```
```git fetch -p```



# Xtrabackup
A wrapper script for the Percona full mysql backup solution. Creates a full backup of the 'mysql datadir' which includes all the databases. Read more on
https://www.percona.com/doc/percona-xtrabackup/2.4/index.html

## installation
After the repository has been cloned or installed via git checkout:
- Copy ```xtrabackup.conf-sample``` to ```xtrabackup.conf```
- Add your config values to ```xtrabackup.conf```
- Add a cron job for root
```10 * * * * /home/wrbeheer/bin/xtrabackup.sh -v 2>&1 >>/var/log/xtrabackup.log```

### Logrotate
- Create a file called ```xtrabackup``` in ```/etc/logrotate.d/```
- Add this config
```
/var/log/xtrabackup.log {
	daily
	missingok
	rotate 7
	compress
	delaycompress
	notifempty
	su root root
}
```

- Change file permission
```chmod 644 /etc/logrotate.d/xtrabackup```

- Run logrotate to test
```logrotate /etc/logrotate.conf --debug```

# Logrotate
- Create a file called ```webraap``` in ```/etc/logrotate.d/```
- Add this config (make sure to change the ```PATHTOWEBRAAPLOG```)

```
PATHTOWEBRAAPLOG.log {
	daily
	missingok
	rotate 7
	compress
	delaycompress
	notifempty
	create 640 root root
}
```

- Change file permission
```chmod 644 /etc/logrotate.d/webraap```

- Run logrotate to test
```logrotate /etc/logrotate.conf --debug```
