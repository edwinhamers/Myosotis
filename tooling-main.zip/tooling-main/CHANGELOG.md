# Changelog postforge,sh

## 0.1 - 19 feb 2025
- Birth


# Changelog wrupdate.sh

## 2.7 - 14 Nov 2023
- Introduced log levels for more granular logging capabilities
- Added -v as argument to list the script and config versions


## 2.6.1 - Patch release
- Added function to check for mysql privileges (when exporting database dumps)
- Better comments and user instructions
- Solved bug with db username and db user global name for wro databases

## 2.6 - 8 Nov 2023
- Added option to delete ALL tables from given database
- Added --dry argument to run script in 'dry run mode'
- Refactored code


## 2.5 - 22 aug 2023
- Added version check for application and configuration.
  - This will ensure that both versions are always matching 
    and older configs are update by the user after a 'selfupdate'
- Added more config checks for non-existing config values
- Cleaned up logging
- Better log separation between the Verbose and debug modes

### Dev
- Update wrupdate.conf to latest version
- xtrabackup.sh and backupmanager.sh removed as they were deprecated
  after implementing the database backup option in 2.4

## 2.4 - 16 aug 2023
- Added database backup utility
  - Action required: update wrupdate.conf!
- Improving comments in config


## 2.3 - 29 sep 2022
- Added self updating functionality.


## 2.2 - Sep 2022
- first release of the branch selection option
- Shelfed the self updating function for now


## 2.1 - Jul 2022
- Added option to update/rebuild all app domains
- Added update option that will update the script itself


## 2.0
- Complete rewrite to follow OOP
- Added many options


## 1.0
- Electronic birth
